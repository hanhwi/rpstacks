#!/usr/bin/env python2.7
# Copyright 2014 Hanhwi Jang, Jaewon Lee, Jae-Eon Jo, and Jangwoo Kim

# Redistribution and  use in  source and binary  forms, with  or without
# modification, are permitted provided that the following conditions are
# met:

# 1.  Redistributions of  source code  must retain  the above  copyright
# notice, this list of conditions and the following disclaimer.

# 2. Redistributions in  binary form must reproduce  the above copyright
# notice, this  list of conditions  and the following disclaimer  in the
# documentation and/or other materials provided with the distribution.

# 3.  Neither the  name of  the copyright  holder nor  the names  of its
# contributors may be  used to endorse or promote  products derived from
# this software without specific prior written permission.

# THIS SOFTWARE  IS PROVIDED BY  THE COPYRIGHT HOLDERS  AND CONTRIBUTORS
# "AS  IS" AND  ANY EXPRESS  OR IMPLIED  WARRANTIES, INCLUDING,  BUT NOT
# LIMITED TO, THE IMPLIED WARRANTIES  OF MERCHANTABILITY AND FITNESS FOR
# A PARTICULAR PURPOSE  ARE DISCLAIMED. IN NO EVENT  SHALL THE COPYRIGHT
# HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
# SPECIAL,  EXEMPLARY,  OR  CONSEQUENTIAL DAMAGES  (INCLUDING,  BUT  NOT
# LIMITED TO, PROCUREMENT OF SUBSTITUTE  GOODS OR SERVICES; LOSS OF USE,
# DATA, OR PROFITS; OR BUSINESS  INTERRUPTION) HOWEVER CAUSED AND ON ANY
# THEORY OF  LIABILITY, WHETHER IN  CONTRACT, STRICT LIABILITY,  OR TORT
# (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN  ANY WAY OUT OF THE USE
# OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

import os
import sys
import glob
import re
import subprocess
import getopt
from pprint import pprint

# TODO: use numpy to accelerate computations
class cpibar:
    ent_name = ['base', 'l1i', 'l1d', 'l2i', 'l2d', 'mem_i',
                'mem_d', 'intmul', 'intdiv', 'fpaddsub', 'fpmuldiv', 'br']
    ent_idx = dict([ (x[1], x[0]) for x in enumerate(ent_name) ])
    def __init__(self, cpi):
        self.base = cpi[0]
        self.l1i = cpi[1]
        self.l1d = cpi[2]
        self.l2i = cpi[3]
        self.l2d = cpi[4]
        self.mem_i = cpi[5]
        self.mem_d = cpi[6]
        self.alu_int_mul = cpi[7]
        self.alu_int_div = cpi[8]
        self.alu_fp_addsub = cpi[9]
        self.alu_fp_muldiv = cpi[10]
        self.br = cpi[11]

        self.l1i_counter = cpi[12]
        self.l2i_counter = cpi[13]
        self.mem_i_counter = cpi[14]
        self.l1d_counter = cpi[15]
        self.l2d_counter = cpi[16]
        self.mem_d_counter = cpi[17]
        self.l1_sharing = cpi[18]
        self.l2_sharing = cpi[19]
        self.bank_sharing = cpi[20]

    def sum(self):
      return self.base + self.l1i + self.l2i + self.l1d \
      + self.l2d + self.mem_i + self.mem_d \
      + self.alu_int_mul + self.alu_int_div + self.alu_fp_addsub + self.alu_fp_muldiv + self.br

    @property
    def list(self):
      return [self.base, self.l1i, self.l1d, self.l2i, self.l2d, self.mem_i, \
        self.mem_d, self.alu_int_mul, self.alu_int_div, self.alu_fp_addsub, self.alu_fp_muldiv, self.br]

    def updatestack(self, p_l1i, p_l2i, p_l1d, p_l2d, p_mem, p_alu_int_mul,
                    p_alu_int_div, p_alu_fp_addsub, p_alu_fp_muldiv, p_base, p_dvfs, p_br):
        adjusted_stack = self.adjust_stack(p_l1i, p_l2i, p_l1d, p_l2d, p_mem,
                                           p_alu_int_mul, p_alu_int_div,
                                           p_alu_fp_addsub, p_alu_fp_muldiv,
                                           p_base, p_dvfs, p_br)
        self.base = adjusted_stack[0]
        self.l1i = adjusted_stack[1]
        self.l1d = adjusted_stack[2]
        self.l2i = adjusted_stack[3]
        self.l2d = adjusted_stack[4]
        self.mem_i = adjusted_stack[5]
        self.mem_d = adjusted_stack[6]
        self.alu_int_mul = adjusted_stack[7]
        self.alu_int_div = adjusted_stack[8]
        self.alu_fp_addsub = adjusted_stack[9]
        self.alu_fp_muldiv = adjusted_stack[10]
        self.br = adjusted_stack[11]

    def adjust_stack(self, p_l1i, p_l2i, p_l1d, p_l2d, p_mem, p_alu_int_mul,
                     p_alu_int_div, p_alu_fp_addsub, p_alu_fp_muldiv,
                     p_base, p_dvfs, p_br):
        # DVFS slows everything down except MEM
        base = self.base * p_dvfs
        l1i = self.l1i * p_dvfs
        l1d = self.l1d * p_dvfs
        l2i = self.l2i * p_dvfs
        l2d = self.l2d * p_dvfs
        alu_int_mul = self.alu_int_mul * p_dvfs
        alu_int_div = self.alu_int_div * p_dvfs
        alu_fp_addsub = self.alu_fp_addsub * p_dvfs
        alu_fp_muldiv = self.alu_fp_muldiv * p_dvfs
        br = self.br * p_dvfs

        l1i = self.l1i * p_l1i
        l2i = self.l2i * p_l2i
        mem_i = self.mem_i * p_mem
        l1d = self.l1d * p_l1d
        l2d = self.l2d * p_l2d
        mem_d = self.mem_d * p_mem
        alu_int_mul = self.alu_int_mul * p_alu_int_mul
        alu_int_div = self.alu_int_div * p_alu_int_div
        alu_fp_addsub = self.alu_fp_addsub * p_alu_fp_addsub
        alu_fp_muldiv = self.alu_fp_muldiv * p_alu_fp_muldiv
        br = self.br * p_br
        base = self.base * p_base

        return [base, l1i, l1d, l2i, l2d, mem_i, mem_d, \
                alu_int_mul, alu_int_div, alu_fp_addsub, alu_fp_muldiv, br]

    def print_out(self):
      print self.base, self.l1i, self.l1d, self.l2i, self.l2d, self.mem_i, \
        self.mem_d, self.alu_int_mul, self.alu_int_div, self.alu_fp_addsub, \
        self.alu_fp_muldiv, self.br
    def __repr__(self):
        return '['  + ' '.join(map(str, self.list)) + ']'

def read_cpi(fname):
    f = open(fname)
    inst_num = int(f.readline())
    f.readline()
    cpi_list = list()
    cpi_reduced_list = list()
    reduced = False
    for line in f:
        if line == 'Reduced Path\n':
            reduced = True
            continue;
        c = cpibar([ int(x) for x in line.split() ])
        if not reduced:
            cpi_list.append(c)
        else:
            cpi_reduced_list.append(c)
    f.close()
    return inst_num, cpi_list, cpi_reduced_list

def cp(cpi_list):
    max_cpi = cpibar([0 for x in range(0, 20)])
    for cpi in cpi_list:
        if cpi.sum() > max_cpi.sum():
            max_cpi = cpi
    return max_cpi

def adjust_stack(cpi_list, item):
    max_cpi = cpibar([0 for x in range(0, 20)])
    for cpi in cpi_list:
        if sum(cpi.adjust_stack(item)) > sum(max_cpi.adjust_stack(item)):
            max_cpi = cpi
    return max_cpi

def getint(fname):
    basename = fname.split('/')[-1]
    return int(re.split('([0-9]+)', basename)[1])

def same(cpi1, cpi2):
    return cpi1.list() == cpi2.list()

def rpstacks_stat(rpstacks_list):
    rpstacks_sz_list = [ len(x) for x in rpstacks_list ]
    total_sz = sum(rpstacks_sz_list)
    avg_sz = total_sz / len(rpstacks_sz_list)
    min_sz, max_sz = min(rpstacks_sz_list), max(rpstacks_sz_list)
    max_blk_idx = 0
    for idx, sz in enumerate(rpstacks_sz_list):
        if sz == max_sz:
            max_blk_idx = idx
            break
    return total_sz, avg_sz, min_sz, max_sz, max_blk_idx

OPTION_LIST = [
    ('help', 'Print options'),
    ('l1i=', 'Adjust L1I$ latency [0<=R<=1, default=1]'),
    ('l2i=', 'Adjust L2I$ latency [0<=R<=1, default=1]'),
    ('l1d=', 'Adjust L1D$ latency [0<=R<=1, default=1]'),
    ('l2d=', 'Adjust L2D$ latency [0<=R<=1, default=1]'),
    ('mem=', 'Adjust MEM latency [0<=R<=1, default=1]'),
    ('br=', 'Adjust branch penalty [0<=R<=1, default=1]'),
    ('intdiv=', 'Adjust INTDIV FU latency [0<=R<=1, default=1]'),
    ('intmul=', 'Adjust INTMUL FU latency [0<=R<=1, default=1]'),
    ('fpaddsub=', 'Adjust FPADDSUB FU latency [0<=R<=1, default=1]'),
    ('fpmuldiv=', 'Adjust FPMULDIV FU latency [0<=R<=1, default=1]'),
    ('base=', 'Adjust base pipeline penalty [0<=R<=1, default=1]'),
    ('dvfs=', 'Apply the performance improvement by dvfs [0<=R<=1, default=1]'),
    ('stat', 'Print # of representative stall-event stacks'),
    ('cp', 'Print critical path into'),
    ('cpi', 'Print the performance in CPI instead of in cycles'),
    ('reduced', 'Use the reduced set of RpStacks')
    ]
def usage():
    print "%s [options] <RpStacks Directory> <RpStacks file prefix>" % sys.argv[0]
    print "Option:"
    for opt in OPTION_LIST:
        if opt[0][-1] == '=':
            print "\t%sR: %s" % (opt[0], opt[1])
        else:
            print "\t%s: %s" % (opt[0], opt[1])

if __name__ == '__main__':
    try:
        option_list = ['help', 'l1i=', 'l2i=', 'l1d=', 'l2d=', 'mem=',
                       'br=', 'stat', 'cp', 'reduced',
                       'intdiv=', 'intmul=', 'fpaddsub=', 'fpmuldiv=',
                       'base=', 'dvfs=', 'cpi']
        opts, args = getopt.getopt(sys.argv[1:], 'ven:f', option_list)
    except getopt.GetoptError as err:
        print str(err)
        usage()
        sys.exit(2)

    output = None
    verbose = False
    stat = False
    cycles = False

    p_l1i = 1.0
    p_l2i = 1.0
    p_l1d = 1.0
    p_l2d = 1.0
    p_br = 1.0
    p_mem = 1.0
    p_alu_int_mul = 1.0
    p_alu_int_div = 1.0
    p_alu_fp_addsub = 1.0
    p_alu_fp_muldiv = 1.0
    p_base = 1.0
    p_dvfs = 1.0
    p_br = 1.0
    enable_cpi = False
    reduced = False
    num_path = -1
    prefix=''
    skip_reading_inst_num_file = False

    for o, a in opts:
        if o == '-v':
            verbose = True
        elif o == '-n':
            num_path = int(a)
        elif o == '--help':
            usage()
            sys.exit(0)
        elif o == '--stat':
            stat = True
        elif o == '--cycles':
            cycles = True
        elif o == '--cpi':
            enable_cpi = True
        elif o == '--l1i':
            p_l1i = float(a)
        elif o == '--l2i':
            p_l2i = float(a)
        elif o == '--l1d':
            p_l1d = float(a)
        elif o == '--l2d':
            p_l2d = float(a)
        elif o == '--mem':
            p_mem = float(a)
        elif o == '--intmul':
            p_alu_int_mul = float(a)
        elif o == '--intdiv':
            p_alu_int_div = float(a)
        elif o == '--fpaddsub':
            p_alu_fp_addsub = float(a)
        elif o == '--fpmuldiv':
            p_alu_fp_muldiv = float(a)
        elif o == '--base':
            p_base = float(a)
        elif o == '--dvfs':
            p_dvfs = float(a)
        elif o == '--br':
            p_br = float(a)
        elif o == '--reduced':
            reduced = True
        elif o == '--prefix':
            prefix=a
        else:
            assert False, "unhandled option"

    if len(args) < 2:
        print "No RpStacks filename"
        usage()
        exit(1)

    rpstacks_dir = args[0]
    prefix = args[1]
    file_list = glob.glob(rpstacks_dir + '/%s_[0-9]*' % prefix)

    if len(file_list) == 0:
        print "Cannot find RpStacks with %s @ %s" % (prefix, rpstacks_dir)
        exit(1)

    #read cpi file
    file_list.sort(key=getint)

    cpi_list_list = list()
    cpi_reduced_list_list = list()
    failed_read = []
    inst_count_list = list()

    for f in file_list:
        try:
            inst_num, cpi_list, cpi_reduced_list = read_cpi(f)
        except:
            failed_read.append(f);
            continue

        cpi_list.sort(key=lambda s: s.sum(), reverse=True)
        cpi_list = cpi_list[0:num_path]
        cpi_reduced_list.sort(key=lambda s: s.sum(), reverse=True)
        cpi_reduced_list = cpi_reduced_list[0:num_path]
        cpi_list_list.append(cpi_list)
        cpi_reduced_list_list.append(cpi_reduced_list)
        inst_count_list.append(inst_num);

    # ideal lat
    for f in failed_read:
        print >> sys.stderr, "[Warn] Failed to read %s" % f

    if cycles:
        print 'Critical Path length'
        print "CPLen[Cycles] BlockSZ[#Insns]"
        for idx, cp in enumerate(cpi_list_list):
            print sum(cp[0].list), inst_count_list[idx]
    elif stat:
        total_sz, avg_sz, min_sz, max_sz, max_blk_idx = \
            rpstacks_stat(cpi_list_list)
        print "Stats on # of paths"
        print 'Total # of paths:', total_sz
        print 'Average # of paths per block :', avg_sz
        print 'Max : %d, Min : %d' % (max_sz, min_sz)
        print 'Largest block index :', max_blk_idx
        print '-' * 40
        rd_total_sz, rd_avg_sz, rd_min_sz, rd_max_sz, rd_max_blk_idx = \
            rpstacks_stat(cpi_reduced_list_list)
        print 'Stats on # of paths (Reduced Paths)'
        print 'Total # of paths:', rd_total_sz
        print 'Average # of paths per block :', rd_avg_sz
        print 'Max : %d, Min : %d' % (rd_max_sz, rd_min_sz)
        print 'Largest block index :', rd_max_blk_idx
        print '-' * 40
    else:
        if reduced:
            cpi_list_list_t = cpi_reduced_list_list
        else:
            cpi_list_list_t = cpi_list_list

        new_cps = []
        cpi_max_key = lambda x : sum(x.adjust_stack(p_l1i, p_l2i, p_l1d, p_l2d,
                                                    p_mem, p_alu_int_mul,
                                                    p_alu_int_div, p_alu_fp_addsub,
                                                    p_alu_fp_muldiv, p_base, p_dvfs, p_br))
        for idx, cpi_list in enumerate(cpi_list_list_t):
            cpi = max(cpi_list, key = cpi_max_key)
            cpi.updatestack(p_l1i, p_l2i, p_l1d, p_l2d, p_mem, p_alu_int_mul,
                            p_alu_int_div, p_alu_fp_addsub, p_alu_fp_muldiv,
                            p_base, p_dvfs, p_br)
            new_cps.append(cpi)
            if verbose:
                print "[Blk%d,SZ=%d]" % (idx, inst_count_list[idx]),
                cpi.print_out()

        output_msg = '=' * 20 + ' Stack Info ' + '=' * 20
        print output_msg
        if enable_cpi:
            total_cpi = [ .0 for i in xrange(0, 12) ]
            for i, cp in enumerate(new_cps):
                for j, ent in enumerate(cp.list):
                    total_cpi[j] +=  ent / int(inst_count_list[i]) # cycle->cpi
            total_cpi = [ x / len(new_cps) for x in total_cpi ]
            for i, cpi in enumerate(total_cpi):
                print cpibar.ent_name[i], cpi
            print '=' * len(output_msg)
            print "CPI", sum(total_cpi)
        else:
            output_msg = '=' * 20 + ' Stack Info ' + '=' * 20
            total_cycles = [ .0 for i in xrange(0, 12) ]
            for cp in new_cps:
                for i, ent in enumerate(cp.list):
                    total_cycles[i] += ent
            for i, cycles in enumerate(total_cycles):
                print cpibar.ent_name[i], cycles
            print '=' * len(output_msg)
            print "#Cycles", sum(total_cycles)
            print "#Insns", sum(inst_count_list)
