// Copyright 2014 Hanhwi Jang, Jaewon Lee, Jae-Eon Jo, and Jangwoo Kim

// Redistribution and  use in  source and binary  forms, with  or without
// modification, are permitted provided that the following conditions are
// met:

// 1.  Redistributions of  source code  must retain  the above  copyright
// notice, this list of conditions and the following disclaimer.

// 2. Redistributions in  binary form must reproduce  the above copyright
// notice, this  list of conditions  and the following disclaimer  in the
// documentation and/or other materials provided with the distribution.

// 3.  Neither the  name of  the copyright  holder nor  the names  of its
// contributors may be  used to endorse or promote  products derived from
// this software without specific prior written permission.

// THIS SOFTWARE  IS PROVIDED BY  THE COPYRIGHT HOLDERS  AND CONTRIBUTORS
// "AS  IS" AND  ANY EXPRESS  OR IMPLIED  WARRANTIES, INCLUDING,  BUT NOT
// LIMITED TO, THE IMPLIED WARRANTIES  OF MERCHANTABILITY AND FITNESS FOR
// A PARTICULAR PURPOSE  ARE DISCLAIMED. IN NO EVENT  SHALL THE COPYRIGHT
// HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
// SPECIAL,  EXEMPLARY,  OR  CONSEQUENTIAL DAMAGES  (INCLUDING,  BUT  NOT
// LIMITED TO, PROCUREMENT OF SUBSTITUTE  GOODS OR SERVICES; LOSS OF USE,
// DATA, OR PROFITS; OR BUSINESS  INTERRUPTION) HOWEVER CAUSED AND ON ANY
// THEORY OF  LIABILITY, WHETHER IN  CONTRACT, STRICT LIABILITY,  OR TORT
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN  ANY WAY OUT OF THE USE
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

#include "Main.hh"
#include <algorithm>
#include <iterator>
#include <cmath>
#include <climits>
#include <cstdlib>

using namespace std;


template <class T>
bool compare_less(pair<int, T> i, pair<int, T> j){
    return i.first <= j.first;
}

template <class T>
bool compare_below_zero(pair<int, T> i){
    return i.first < 0;
}

void Main::clear_buffer(){
    for (static_queue<macroOp, buffer_size>::size_type i = 0; i != mop_list.size(); ++i){
        if(!mop_list[i].isvalid())
            break;
        mop_list[i].print(cout);
        mop_list[i].clear();
        num_insts += mop_list[i].size();
    }
}

void Main::verify(vector <u_int64_t> &results, u_int64_t ref){
    sort(results.begin(), results.end());
    verify(results.back(), ref);
}

void Main::verify(u_int64_t result, u_int64_t ref){
    if (!(result == ref)){
        if (!ignore){
            //cerr << result << " " << ref << "\n";
            assert(0);
        }
        else
        {
            //cerr << "[DIFF] " << (int) (result - ref) << "\n";
            //assert(0);
            error_state_num++;
        }
    }
    return;
}

uop *Main::cacheline_wakeup(){
    uop *target;
    if (!cacheline_wakeup_counter.empty() && cacheline_wakeup_counter[0].first == 0)
        target = cacheline_wakeup_counter[0].second;
    else
        target = NULL;
    return target;
}

void Main::cacheline_counter_tick (){
    int end = cacheline_wakeup_counter.size();
    for (int i = 0; i < end; ++i)
        --cacheline_wakeup_counter[i].first;
    cacheline_wakeup_counter.erase(remove_if(cacheline_wakeup_counter.begin(),
                                             cacheline_wakeup_counter.end(),
                                             compare_below_zero<uop *>),
                                   cacheline_wakeup_counter.end());
    return;
}

void Main::cacheline_counter_add(int wakeup, uop* wakeup_uop){
    if (wakeup > 0){
        cacheline_wakeup_counter.push_back(make_pair(wakeup, wakeup_uop));
        sort(cacheline_wakeup_counter.begin(), cacheline_wakeup_counter.end(), compare_less<uop *>);
    }
}

void Main::issueq_insert(u_int64_t cycles, int idx){
    vector<pair<u_int64_t, int> >::iterator it;
    for (it = issueq.begin(); it != issueq.end(); ++it)
        if (it->first < cycles)
            break;
    issueq.insert(it, make_pair(cycles, idx));
    if (issueq.size() > issueq_size)
        issueq.pop_back();
}

int Main::find_freereg(int find_reg, int &target_idx){
    int idx = prev_idx[RightAhead];
    int count = this->count - 1;
    while (count != 0 && idx != prev_idx[ROBAhead]){
        if (buffer[idx].get_free_reg() == find_reg){
            target_idx = idx;
            return true;
        }
        else {
            vector<int> &pending_free_regs = buffer[idx].get_pending_free_regs();
            vector<int>::iterator it = find(pending_free_regs.begin(),
                                            pending_free_regs.end(),
                                            find_reg);
            if (it != pending_free_regs.end()){
                target_idx = idx;
                return false;
            }
        }
        idx = (idx - 1 + buffer_size) % buffer_size;
        --count;
    }
    target_idx = -1;
    return true;
}

int Main::find_lsq(){
    unsigned int num_ls = 0;
    int idx = prev_idx[RightAhead];
    int count = this->count - 1;
    while (count != 0 && idx != prev_idx[ROBAhead]){
        uop &target_uop = buffer[idx];
        if (target_uop.isload() || target_uop.isstore() || target_uop.ismf()){
            num_ls++;
            if (num_ls == lsq_size)
                return idx;
        }
        idx = (idx - 1 + buffer_size) % buffer_size;
        --count;
    }
    return -1;
}

int Main::find_ldq(){
    unsigned int num_ld = 0;
    int idx = prev_idx[RightAhead];
    int count = this->count - 1;
    while (count != 0 && idx != prev_idx[ROBAhead]){
        uop &target_uop = buffer[idx];
        if (target_uop.isload()){
            num_ld++;
            if (num_ld == ldq_size)
                return idx;
        }
        idx = (idx - 1 + buffer_size) % buffer_size;
        --count;
    }
    return -1;
}

int Main::find_stq(){
    unsigned int num_st = 0;
    int idx = prev_idx[RightAhead];
    int count = this->count - 1;
    while (count != 0 && idx != prev_idx[ROBAhead]){
        uop &target_uop = buffer[idx];
        if (target_uop.isstore() || target_uop.ismf()){
            num_st++;
            if (num_st == stq_size)
                return idx;
        }
        idx = (idx - 1 + buffer_size) % buffer_size;
        --count;
    }
    return -1;
}

Main::Main(static_queue <macroOp, buffer_size>& mop_list, bool ignore)
    :idx(0), error_state_num(0), total(0), num_insts(0),
     count(0), ignore(ignore), mop_list(mop_list)
{
    prev_idx[RightAhead] = buffer_size  - 1;
    prev_idx[FWAhead] = buffer_size - fetch_width;
    prev_idx[FQAhead] = buffer_size - fq_size;
    prev_idx[FRAhead] = buffer_size - frontend_width;
    prev_idx[DWAhead] = buffer_size - dispatch_width;
    prev_idx[CWAhead] = buffer_size - commit_width;
    prev_idx[ROBAhead] = buffer_size - rob_size;
    prev_idx[IQAhead] = buffer_size - issueq_size;

    //Reserve
    cacheline_wakeup_counter.reserve(10);
    issueq.reserve(issueq_size);

    //init
    uop::init_map();
    uop::set_buffer(buffer, buffer_size);
    macroOp::set_renaming_table(&renaming_table);
}

void Main::start(){
    u_int64_t commit_cycle = 0;
    u_int64_t commit_ref_cycle = 0;
    u_int64_t start_cycle = 0;
    int idx_mop = 0;

    while(1){
        if (count == buffer_size){
            macroOp &evicted_mop = mop_list.front();
            assert(evicted_mop.isvalid());
            evicted_mop.print(cout);
            //clear renaming table entry
            evicted_mop.clear();
            //Release renaming_table entry
            int num_evicted_uops = evicted_mop.size();
            num_insts += num_evicted_uops;
            count -= num_evicted_uops;
            mop_list.pop_front();
        }

        //Trace entry read from standard IO
        uop &cur_uop = buffer[idx];
        uop &prev_uop = buffer[prev_idx[RightAhead]];
        if (!cur_uop.init())
            break;
        u_int64_t id = cur_uop.get_id();
        int prev_idx_mop[PrevIdxNum];

        if (cur_uop.issom()){
            idx_mop = idx;
            for (int i = 0; i < PrevIdxNum; i++)
                prev_idx_mop[i] = prev_idx[i];
        }

        count++;
        // Flush memory depdency table when misprediction occurs
        // if (cur_uop.br_miss() || cur_uop.first_br_miss()){
        //     cacheline_wakeup_counter.clear();
        // }

        // Search STS for address and data dependency
        if (cur_uop.isload()){
            int ls_count = 1; // include itself
            int icount = 1; // --
            int idx = prev_idx[RightAhead];
            set<int> &addr_deps = cur_uop.get_addr_deps();
            set<int> &data_deps = cur_uop.get_data_deps();
#ifdef DEBUG
            cerr << cur_uop.get_id() << '\n';
            cerr << "BEFORE" << '\n';
            copy (addr_deps.begin(), addr_deps.end(), ostream_iterator<int>(cerr, " "));
            cerr << endl;
            // DATA DEPS
            copy(data_deps.begin(), data_deps.end(), ostream_iterator<int>(cerr, " "));
            cerr << endl;
#endif
            while (icount < count && icount < rob_size && ls_count < lsq_size){
                ++icount;
                uop &uop_t = buffer[idx];
                if (uop_t.isload())
                    ++ls_count;
                else if (uop_t.isstore()){
                    // Check physaddr
                    int reg_rd = uop_t.get_regid(RD);
                    int addr_diff = cur_uop.get_physaddr() - uop_t.get_physaddr();
                    addr_deps.insert(reg_rd);
                    if (-1 <= addr_diff && addr_diff <= 1){ // The load depends on this store
                        data_deps.insert(reg_rd);
                    }
                    ++ls_count;
                }
                else{
                    ;
                }
                if (idx == 0)
                    idx = buffer_size - 1;
                else
                    --idx;
            }
            // ADDR DEPS
#ifdef DEBUG
            cerr << "AFTER" << '\n';
            std::copy(addr_deps.begin(), addr_deps.end(), ostream_iterator<int>(cerr, " "));
            cerr << endl;
            // DATA DEPS
            std::copy(data_deps.begin(), data_deps.end(), ostream_iterator<int>(cerr, " "));
            cerr << endl;
#endif
        }

        //Build state in instruction
        //Fetch
        cur_uop.access_state(Fetch).init(Fetch);
        vector <u_int64_t> fetch_results;
        if (id >= fetch_width){
            fetch_results.push_back(buffer[prev_idx[FWAhead]].add_edge(id, Fetch, ICache));
        }
        //Inorder Fetch && branch miss
        if (id >= 1){
            fetch_results.push_back(prev_uop.add_edge(id, Fetch, ICache));
            if (prev_uop.br_miss()){
                fetch_results.push_back(prev_uop.add_edge(id, Fetch, Issue));
            }
        }
        else{
            start_cycle = cur_uop.fq_in_cycle();
            cout << start_cycle << '\n';
            fetch_results.push_back(cur_uop.fq_in_cycle());
        }

        if (id >= fq_size){
            fetch_results.push_back(buffer[prev_idx[FQAhead]].add_edge(id, Fetch, Rename));
        }

        //verifying fetch
        verify(fetch_results, cur_uop.fq_in_cycle());
        if (ignore)
            cur_uop.set_cycle(Fetch, cur_uop.fq_in_cycle());
        else
            cur_uop.set_cycle(Fetch, fetch_results.back());


        //ITLB
        cur_uop.access_state(ITLB).init(ITLB);
        u_int64_t itlb_cycle = cur_uop.add_edge(id, ITLB, Fetch);
        verify(itlb_cycle, cur_uop.itlb_cycle());
        if (ignore)
            cur_uop.set_cycle(ITLB, cur_uop.itlb_cycle());
        else
            cur_uop.set_cycle(ITLB, itlb_cycle);

        //Icache
        cur_uop.access_state(ICache).init(ICache);
        u_int64_t icache_cycle = cur_uop.add_edge(id, ICache, ITLB);
        verify(icache_cycle, cur_uop.icache_cycle());
        if (ignore)
            cur_uop.set_cycle(ICache, cur_uop.icache_cycle());
        else
            cur_uop.set_cycle(ICache, icache_cycle);

        //Rename
        cur_uop.access_state(Rename).init(Rename);
        vector <u_int64_t> rename_results;
        rename_results.push_back(cur_uop.add_edge(id, Rename, ICache));
        if (id >= rob_size){
            rename_results.push_back(buffer[prev_idx[ROBAhead]].add_edge(id, Rename, Commit));
        }
        if (id >= 1){
            rename_results.push_back(buffer[prev_idx[RightAhead]].add_edge(id, Rename, Rename));
        }
        if (id >= frontend_width){
            rename_results.push_back(buffer[prev_idx[FRAhead]].add_edge(id, Rename, Rename));
        }

        // Default : 0
        // Add_edge function's AUX : ROB => 0, REG => 1, LDQ => 2, STQ => 3, LSQ => 4

        vector<pair<int, int> > res_deps;
        //Find physical register
        {
            int target_idx;
            if (find_freereg(cur_uop.get_regid(RD), target_idx))
                res_deps.push_back(make_pair(target_idx, 1));
            else
                rename_results.push_back(buffer[target_idx].add_edge(id, Rename, Rename, 1));
        }
        if (cur_uop.isload()){
            //Find LDQ
            res_deps.push_back(make_pair(find_ldq(), 2));
            res_deps.push_back(make_pair(find_lsq(), 4));
        }
        else if (cur_uop.isstore() || cur_uop.ismf()){
            res_deps.push_back(make_pair(find_stq(), 3));
            res_deps.push_back(make_pair(find_lsq(), 4));
        }

        for (vector<pair<int, int> >::iterator it = res_deps.begin(); it != res_deps.end(); ++it){
            if ((*it).first != -1)
                rename_results.push_back(buffer[(*it).first].add_edge(id, Rename, Commit, (*it).second));
        }

        verify(rename_results, cur_uop.rename_done_cycle());
        if (ignore)
            cur_uop.set_cycle(Rename, cur_uop.rename_done_cycle());
        else
            cur_uop.set_cycle(Rename, rename_results.back());
        //Dispatch
        cur_uop.access_state(Dispatch).init(Dispatch);
        vector <u_int64_t> dispatch_results;
        dispatch_results.push_back(cur_uop.add_edge(id, Dispatch, Rename));

        //
        // 140518 spiegel0
        // - Issue queue entering dependency
        // - Insert perturbation to cope with issue dynamics

        //  140518 Instruction-type perturbation code -- not working well for 410.bwaves
        // - Classify instructions in the ROB-range into few types
        // - Refer to inst.hh for details
        // - Among the same type of instrs, select the most recent one with issue cycle < my dispatch cycle

        if (id >= rob_size)
        {
            int num_instruction_type = 7;
            int closest_instruction_distance[num_instruction_type];
            u_int64_t closest_instruction_dispatch_cycle[num_instruction_type];
            int closest_instruction_index[num_instruction_type];
            bool closest_instruction_waiton_opt_insn[num_instruction_type];

            // Initialize arrays
            for (int i = 0; i < num_instruction_type; i++)
            {
              closest_instruction_distance[i] = INT_MAX;
              closest_instruction_dispatch_cycle[i] = 0;
              closest_instruction_index[i] = -1;
              closest_instruction_waiton_opt_insn[i] = false;
            }
            //cerr << "[IssueDep] Cur idx: " << idx << " ROBAhead idx: " <<  prev_idx[ROBAhead] << endl;

            // Search ROB!
            for (int i = prev_idx[ROBAhead]; i < prev_idx[ROBAhead] + rob_size; i++)
            {
              int i_circular = i % buffer_size;

              u_int64_t target_dispatch_cycle = buffer[i_circular].dispatch_cycle();
              int diff = (int)(cur_uop.dispatch_cycle() - buffer[i_circular].issue_cycle());

              int instruction_type = buffer[i_circular].instruction_type();
              //cerr << "[IssueDep] Instruction type: " << instruction_type << " Diff: " << diff << endl;

              if (diff <= closest_instruction_distance[instruction_type] && diff >= 0 &&
                target_dispatch_cycle > closest_instruction_dispatch_cycle[instruction_type])
              {
                closest_instruction_distance[instruction_type] = diff;
                closest_instruction_dispatch_cycle[instruction_type] = target_dispatch_cycle;
                closest_instruction_index[instruction_type] = i_circular;

                bool is_waiton_opt_insn = true;
                for (int j = RA; j <= RC; j++)
                {
                  map<int, uop*>::iterator target_uop = renaming_table.find(buffer[i_circular].get_regid(j));
                  if(target_uop != renaming_table.end() && target_uop->second->instruction_type() == 2)
                  {
                    is_waiton_opt_insn = false;
                    break;
                  }
                }
                closest_instruction_waiton_opt_insn[instruction_type] = is_waiton_opt_insn;
              }
            }

            // Now, create dependency edge

            // First, check if there's an instruction waiting for opt-available instruction
            bool waiton_opt_insn_exists = false;
            bool waiton_opt_insn_bitmap[num_instruction_type];
            for (int i = 0; i < num_instruction_type; i++)
            {
              if (closest_instruction_waiton_opt_insn[i] == true)
              {
                waiton_opt_insn_exists = true;
                waiton_opt_insn_bitmap[i] = true;
              }
              else
                waiton_opt_insn_bitmap[i] = false;
            }

            // Try the best to select an instruction with opt-availability
            int random_int;
            int deadlock_counter = 0;
            int issue_dependency_index = -1;

            while (issue_dependency_index == -1 && (deadlock_counter < 20))
            {
              random_int = rand() % num_instruction_type;
              issue_dependency_index = closest_instruction_index[random_int];
              deadlock_counter++;

              // Nullify the selection
              if (waiton_opt_insn_exists == true && issue_dependency_index != -1)
                if(waiton_opt_insn_bitmap[issue_dependency_index] == false)
                {
                  deadlock_counter--;
                  issue_dependency_index = -1;
                }
            }

            // DEBUG
            // cerr << "Random num: " << random_int << " Index: " << issue_dependency_index << endl;
            // cerr << "Index/distance/opt-availability of closest instructions ";
            // for (int i = 0; i < num_instruction_type; i++)
            //    cerr << closest_instruction_index[i]
            //    << "/" << closest_instruction_distance[i]
            //    << "/" << waiton_opt_insn_bitmap[i] << "  ";
            //  cerr << endl;
            if (issue_dependency_index != -1){
              dispatch_results.push_back(buffer[issue_dependency_index].add_edge(id, Dispatch, Issue));
            }
        }

        //InorderDispatch
        if (id >= 1)
            dispatch_results.push_back(prev_uop.add_edge(id, Dispatch, Dispatch));
        if (id >= dispatch_width)
            dispatch_results.push_back(buffer[prev_idx[DWAhead]].add_edge(id, Dispatch, Dispatch));

        // //Issue Queue Shortage Modeling
        // if (id >= issueq_size){
        //   int target = issueq.back().second;
        //   dispatch_results.push_back(buffer[target].add_edge(id, Dispatch, Issue));
        // }
        verify(dispatch_results, cur_uop.dispatch_cycle());
        if (ignore)
            cur_uop.set_cycle(Dispatch, cur_uop.dispatch_cycle());
        else
            cur_uop.set_cycle(Dispatch, dispatch_results.back());


        //Ready
        vector <u_int64_t> ready_results;
        if (cur_uop.isload() || cur_uop.isstore()){
            //AddrReady
            //RaRbRs
            cur_uop.access_state(AddrReady).init(AddrReady);
            vector<u_int64_t> addrready_results;
            addrready_results.push_back(cur_uop.add_edge(id, AddrReady, Dispatch));
            for (int i = RA; i <= RB; i++){
                map<int, uop*>::iterator target_uop = renaming_table.find(cur_uop.get_regid(i));
                if(target_uop != renaming_table.end())
                    addrready_results.push_back(target_uop->second->add_edge(id, AddrReady, Complete));
            }
            //RS for mf.
            map<int, uop*>::iterator target_uop = renaming_table.find(cur_uop.get_regid(MF));
            if (target_uop != renaming_table.end())
                addrready_results.push_back(target_uop->second->add_edge(id, AddrReady, Complete));

            //verifying addr ready cycle
            verify(addrready_results, cur_uop.addrready_cycle());
            if (ignore)
                cur_uop.set_cycle(AddrReady, cur_uop.addrready_cycle());
            else
                cur_uop.set_cycle(AddrReady, addrready_results.back());

            //AddrGen
            cur_uop.access_state(AddrGen).init(AddrGen);
            u_int64_t addrgen_cycle = cur_uop.add_edge(id, AddrGen, AddrReady);
            verify(addrgen_cycle, cur_uop.addrgen_cycle());
            if (ignore)
                cur_uop.set_cycle(AddrGen, cur_uop.addrgen_cycle());
            else
                cur_uop.set_cycle(AddrGen, addrgen_cycle);

            //DTLB
            cur_uop.access_state(DTLB).init(DTLB);
            u_int64_t dtlb_cycle = cur_uop.add_edge(id, DTLB, AddrGen);
            verify(dtlb_cycle, cur_uop.dtlb_cycle());
            if (ignore)
                cur_uop.set_cycle(DTLB, cur_uop.dtlb_cycle());
            else
                cur_uop.set_cycle(DTLB, dtlb_cycle);
            //Ready for ld/st
            cur_uop.access_state(Ready).init(Ready);
            ready_results.push_back(cur_uop.add_edge(id, Ready, DTLB));
        }
        else{
            //Ready for ALU
            cur_uop.access_state(Ready).init(Ready);
            ready_results.push_back(cur_uop.add_edge(id, Ready, Dispatch));
        }


        if (cur_uop.isload()){
            for (int i = RA; i <= RS; i++){
                map<int, uop*>::iterator target_uop = renaming_table.find(cur_uop.get_regid(i));
                if(target_uop != renaming_table.end())
                    ready_results.push_back(target_uop->second->add_edge(id, Ready, Complete));
            }
            //Address dep
            set<int> &addr_deps = cur_uop.get_addr_deps();
            for (set<int>::iterator it = addr_deps.begin(); it != addr_deps.end(); ++it){
                if (*it == cur_uop.get_regid(RS))
                    continue;
                map<int, uop*>::iterator target_uop = renaming_table.find(*it);
                if(target_uop != renaming_table.end()){
                    //ready_results.push_back(target_uop->second->add_edge(id, Ready, AddrGen)); // DTLB
                    ready_results.push_back(target_uop->second->add_edge(id, Ready, DTLB)); // DTLB
                }
            }
        }
        else {
            for (int i = RA; i <= RS; i++){
                map<int, uop*>::iterator target_uop = renaming_table.find(cur_uop.get_regid(i));
                if(target_uop != renaming_table.end())
                    ready_results.push_back(target_uop->second->add_edge(id, Ready, Complete));
            }
        }

        //Check result cycles
        verify(ready_results, cur_uop.ready_cycle());
        if (ignore)
            cur_uop.set_cycle(Ready, cur_uop.ready_cycle());
        else
            cur_uop.set_cycle(Ready, ready_results.back());

        //Issue
        cur_uop.access_state(Issue).init(Issue);
        vector<u_int64_t> issue_results;

        if (cur_uop.isload()){
            set<int> &data_deps = cur_uop.get_data_deps();
            for (set<int>::iterator it = data_deps.begin(); it != data_deps.end(); ++it){
                if (*it == cur_uop.get_regid(RS))
                    continue;
                map<int, uop*>::iterator target_uop = renaming_table.find(*it);
                if(target_uop != renaming_table.end())
                    // Every load should wait to issue until all previous dependent stores have address and data.
                    // However, load can issue with previous store, so conservatively we add edge b/w the stores' issue and load issue
                    issue_results.push_back(target_uop->second->add_edge(id, Issue, Issue));
            }
        }

        //Complete
        vector<u_int64_t>complete_results;
        cur_uop.access_state(Complete).init(Complete);

        uop *wakeup_uop = cacheline_wakeup();
        // Cacheline Sharing
        bool need_revert = false;
        int propagated_dmiss = 0;

        if (cur_uop.isload() && wakeup_uop){
            // Check cachelines of the uop that wakes up cur_uop and cachelines of cur_uop
            // If they match, set cur_uop dmiss as Wait state

            int aux;
            // Add edge for cacheline shareing
            if ((wakeup_uop->get_robid() == cur_uop.get_who_wakeup())
                && wakeup_uop->cacheline_match(cur_uop.get_cachelines(), aux)){
                //if ((aux > 1) || (cur_uop.complete_cycle() - wakeup_uop->complete_cycle()) < 1) {
                    // Before adding cache line edge, it changes dcache miss status to 'Wait'
                    cur_uop.clear_dmiss();
                    // if (aux <= 1){
                    //     if (cur_uop.complete_cycle() - wakeup_uop->complete_cycle() > 1){
                    //         cerr << "F " << cur_uop.fetch_cycle() << " " << wakeup_uop->fetch_cycle() << endl;
                    //         cerr << cur_uop.complete_cycle() << " " << wakeup_uop->complete_cycle() << endl;
                    //     }
                    // }
                    complete_results.push_back(wakeup_uop->add_edge(id, Complete, Complete, aux));
                    // Set cur_uops's dmiss status same as its dependent ups's dmiss status,
                    // so that the status can be propagated throught cache line sharing edge.
                    //  cur_uop.set_dmiss(wakeup_uop->get_dmiss());
                    need_revert = true;
                    propagated_dmiss = wakeup_uop->get_dmiss();
                    //}
            }

            // Set issue cycles
            issue_results.push_back(cur_uop.add_edge(id, Issue, Ready));
            verify(issue_results, cur_uop.issue_cycle());
            if (ignore)
                cur_uop.set_cycle(Issue, cur_uop.issue_cycle());
            else
                cur_uop.set_cycle(Issue, issue_results.back());
        }
        else {
            issue_results.push_back(cur_uop.add_edge(id, Issue, Ready));
            verify(issue_results, cur_uop.issue_cycle());
            if (ignore)
                cur_uop.set_cycle(Issue, cur_uop.issue_cycle());
            else
                cur_uop.set_cycle(Issue, issue_results.back());
        }

        //Complete : Issue to Complete
        complete_results.push_back(cur_uop.add_edge(id, Complete, Issue));
        verify(complete_results, cur_uop.complete_cycle());
        if (ignore)
            cur_uop.set_cycle(Complete, cur_uop.complete_cycle());
        else
            cur_uop.set_cycle(Complete, complete_results.back());

        if (need_revert)
            cur_uop.set_dmiss(propagated_dmiss);

        //InorderCommit //CommitWidth
        if (cur_uop.iseom()){
            //1
            uop &first = buffer[idx_mop];
            int som_id = first.get_id();
            int i;
            int end = (idx + 1) % buffer_size;
            first.access_state(ReadyToCommit).init(ReadyToCommit);
            vector<u_int64_t> commit_ready_results;
            for (i = idx_mop; i != end; i = (i + 1) % buffer_size){
                if (buffer[i].ismf()){
                    commit_ready_results.push_back(buffer[i].add_edge(som_id, ReadyToCommit, Issue));
                }
                else{
                    commit_ready_results.push_back(buffer[i].add_edge(som_id, ReadyToCommit, Complete));
                }
            }

            //Inorder Commit & Commit Width Limit
            for (i = idx_mop; i != end; i = (i + 1) % buffer_size){
                u_int64_t id = buffer[i].get_id();
                if (i != idx_mop)
                    buffer[i].access_state(ReadyToCommit).init(ReadyToCommit);
                if (id >= 1)
                    commit_ready_results.push_back(buffer[prev_idx_mop[RightAhead]].add_edge(id, ReadyToCommit, Commit));
                if (id >= commit_width)
                    commit_ready_results.push_back(buffer[prev_idx_mop[CWAhead]].add_edge(id, ReadyToCommit, Commit));

                if (buffer[i].ismf()){
                    commit_ready_results.push_back(buffer[i].add_edge(id, ReadyToCommit, Complete));
                }

                sort(commit_ready_results.begin(), commit_ready_results.end());

                buffer[i].set_cycle(ReadyToCommit, commit_ready_results.back());

                //Commit Cycle
                buffer[i].access_state(Commit).init(Commit);
                total = buffer[i].access_state(Commit).get_idx();
                commit_cycle = buffer[i].add_edge(id, Commit, ReadyToCommit);
                commit_ref_cycle = buffer[i].commit_cycle();

                verify(commit_cycle, commit_ref_cycle);
                if (ignore)
                    buffer[i].set_cycle(Commit, commit_ref_cycle);
                else
                    buffer[i].set_cycle(Commit, commit_cycle);

                for (int j = 0; j < PrevIdxNum; j++){
                    prev_idx_mop[j]++;
                    if (prev_idx_mop[j] == buffer_size)
                        prev_idx_mop[j] = 0;
                }
                commit_ready_results.clear();
            }
        }

        //Update issueq table
        //deprecated
        //issueq_insert(cur_uop.access_state(Issue).get_cycle(), idx);

        //Update cacheline
        if (cur_uop.isload()){
            std::vector<int> &wakeup_distance = cur_uop.get_wakeup();
            for (int i = 0; i < wakeup_distance.size(); ++i){
                cacheline_counter_add(wakeup_distance[i], &cur_uop);
            }
        }
        cacheline_counter_tick();

        //Update Renaming table
        map<int, uop*>::iterator update_rt_it = renaming_table.find(cur_uop.get_regid(RD));
        if (update_rt_it != renaming_table.end()){
            //update
            update_rt_it->second = &cur_uop;
        }
        else {
            assert(cur_uop.get_regid(RD) != 0);
            renaming_table.insert(make_pair(cur_uop.get_regid(RD), &cur_uop));
        }

        //Advance indexes
        idx++;
        if (idx == buffer_size)
            idx = 0;
        for (int i = 0; i < PrevIdxNum; i++){
            prev_idx[i]++;
            if (prev_idx[i] == buffer_size)
                prev_idx[i] = 0;
        }
    }
    clear_buffer();

    if (num_insts == 0)
        return;
    else{
        cerr << "=============== Stats ===============" << endl;
        cerr << "Processed Insns : " << num_insts << endl;
        cerr << "Error Node : " << error_state_num << ", Total : " << total << endl;
        cerr << "Trace Start Cycles: " << start_cycle << endl;
        cerr << "Trace End Cycles: " << commit_ref_cycle
             << ", Trace Exec. Cycles: " << (commit_ref_cycle - start_cycle) << endl;
        cerr << "Graph End Cycles: " << commit_cycle
             << ", Graph Exec. Cycles: " << (commit_cycle - start_cycle) << endl;
    }
}
