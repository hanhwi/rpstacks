// Copyright 2014 Hanhwi Jang, Jaewon Lee, Jae-Eon Jo, and Jangwoo Kim

// Redistribution and  use in  source and binary  forms, with  or without
// modification, are permitted provided that the following conditions are
// met:

// 1.  Redistributions of  source code  must retain  the above  copyright
// notice, this list of conditions and the following disclaimer.

// 2. Redistributions in  binary form must reproduce  the above copyright
// notice, this  list of conditions  and the following disclaimer  in the
// documentation and/or other materials provided with the distribution.

// 3.  Neither the  name of  the copyright  holder nor  the names  of its
// contributors may be  used to endorse or promote  products derived from
// this software without specific prior written permission.

// THIS SOFTWARE  IS PROVIDED BY  THE COPYRIGHT HOLDERS  AND CONTRIBUTORS
// "AS  IS" AND  ANY EXPRESS  OR IMPLIED  WARRANTIES, INCLUDING,  BUT NOT
// LIMITED TO, THE IMPLIED WARRANTIES  OF MERCHANTABILITY AND FITNESS FOR
// A PARTICULAR PURPOSE  ARE DISCLAIMED. IN NO EVENT  SHALL THE COPYRIGHT
// HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
// SPECIAL,  EXEMPLARY,  OR  CONSEQUENTIAL DAMAGES  (INCLUDING,  BUT  NOT
// LIMITED TO, PROCUREMENT OF SUBSTITUTE  GOODS OR SERVICES; LOSS OF USE,
// DATA, OR PROFITS; OR BUSINESS  INTERRUPTION) HOWEVER CAUSED AND ON ANY
// THEORY OF  LIABILITY, WHETHER IN  CONTRACT, STRICT LIABILITY,  OR TORT
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN  ANY WAY OUT OF THE USE
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

#ifndef _MAIN_HH
#define _MAIN_HH

#include <sys/types.h>
#include <map>
#include <vector>
#include "queue.hh"
#include "inst.hh"
#include "const.hh"

enum {RightAhead, FWAhead, FQAhead, FRAhead, DWAhead, CWAhead, \
      ROBAhead, IQAhead, PrevIdxNum};

class Main{
private:
    static const int buffer_size = uop_buffer_size;
    int idx;
    //record # of states that can't pass verify function
    u_int64_t error_state_num;
    //total # of states
    u_int64_t total;
    //total $ of inst
    u_int64_t num_insts;
    int prev_idx[PrevIdxNum];
    unsigned int count;
    bool ignore;
    uop buffer[buffer_size];
    std::map<int, uop *> renaming_table;
    static_queue<macroOp, buffer_size> &mop_list;
    std::vector<std::pair<int, uop *> > cacheline_wakeup_counter;
    std::vector<std::pair<u_int64_t, int> > issueq;
    void clear_buffer();
    void verify(std::vector <u_int64_t> &results, u_int64_t ref);
    void verify(u_int64_t result, u_int64_t ref);
    uop *cacheline_wakeup();
    void cacheline_counter_tick();
    void cacheline_counter_add(int wakeup, uop* wakeup_uop);
    void issueq_insert(u_int64_t cycles, int idx);
    int find_freereg(int find_reg, int &target_idx);
    int find_lsq();
    int find_ldq();
    int find_stq();
public:
    Main(static_queue<macroOp, buffer_size> &, bool ignore = false);
    void start();
};

#endif
