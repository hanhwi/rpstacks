// Copyright 2014 Hanhwi Jang, Jaewon Lee, Jae-Eon Jo, and Jangwoo Kim

// Redistribution and  use in  source and binary  forms, with  or without
// modification, are permitted provided that the following conditions are
// met:

// 1.  Redistributions of  source code  must retain  the above  copyright
// notice, this list of conditions and the following disclaimer.

// 2. Redistributions in  binary form must reproduce  the above copyright
// notice, this  list of conditions  and the following disclaimer  in the
// documentation and/or other materials provided with the distribution.

// 3.  Neither the  name of  the copyright  holder nor  the names  of its
// contributors may be  used to endorse or promote  products derived from
// this software without specific prior written permission.

// THIS SOFTWARE  IS PROVIDED BY  THE COPYRIGHT HOLDERS  AND CONTRIBUTORS
// "AS  IS" AND  ANY EXPRESS  OR IMPLIED  WARRANTIES, INCLUDING,  BUT NOT
// LIMITED TO, THE IMPLIED WARRANTIES  OF MERCHANTABILITY AND FITNESS FOR
// A PARTICULAR PURPOSE  ARE DISCLAIMED. IN NO EVENT  SHALL THE COPYRIGHT
// HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
// SPECIAL,  EXEMPLARY,  OR  CONSEQUENTIAL DAMAGES  (INCLUDING,  BUT  NOT
// LIMITED TO, PROCUREMENT OF SUBSTITUTE  GOODS OR SERVICES; LOSS OF USE,
// DATA, OR PROFITS; OR BUSINESS  INTERRUPTION) HOWEVER CAUSED AND ON ANY
// THEORY OF  LIABILITY, WHETHER IN  CONTRACT, STRICT LIABILITY,  OR TORT
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN  ANY WAY OUT OF THE USE
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

#include "inst.hh"
#include <vector>
#include <algorithm>
#include <iterator>

using namespace std;

int pad = 0;
const char * edge_type_name[] = { GEN_EDGE_TYPE(GEN_NAME) };
const char * penalty_name[] =  { GEN_PENALTY_TYPE(GEN_NAME) };

template <class t>
ostream &operator ,(ostream &os, t c){
    return os << ' ' << c;
}

//_trace_info
bool _trace_info::load(){
    //initialize storage vector for data and add deps
    data_deps.clear();
    addr_deps.clear();

    cin >> som
        >> eom
        >> redispatch
        >> opcode
        >> alutype
        >> reg_rd
        >> reg_ra
        >> reg_rb
        >> reg_rc
        >> reg_rs
        >> reg_mf
        >> fetch
        >> fq_in_delay
        >> itlb_delay
        >> icache_delay
        >> rename_try_delay
        >> rename_rob_suf_cond_delay
        >> rename_physreg_suf_cond_delay
        >> rename_ldq_suf_cond_delay
        >> rename_stq_suf_cond_delay
        >> rename_lsq_suf_cond_delay
        >> rename_delay
        >> iq_full_delay
        >> dispatch_delay;

    if (!cin.good())
        return false;

    if (redispatch)
        cin >> redispatch_delay;

    if (isload() || isstore()){
        cin >> addrgen_ready_delay
            >> addrgen_delay
            >> dtlb_delay;
    }

    cin >> ready_delay
        >> issue_delay
        >> complete_delay
        >> ready_to_commit_delay
        >> commit_delay;

    cin >> store_dcache_stall
        >> exception_stall
        >> smc_stall
        >> memlocked;

    cin.ignore(10, 'B');
    cin >> barrier;

    cin.ignore(10, 'S');
    cin.ignore(10, 'T');
    cin >> stop;

    cin.ignore(10, 'I');
    cin.ignore(10, 'N');
    cin.ignore(10, 'T');
    cin >> interrupt;

    cin.ignore(10, 'F');
    cin >> fu_lat;

    cin.ignore(10, 'I');
    bool temp[2];
    for (int i = 0; i < 2; i++){
        cin >> temp[i];
    }

    icache = L1Hit;
    for (int i = 0; i < 2; i++)
        if (temp[i]){
            icache = i + L2Hit;
        }

    cin.ignore(10, 'D');
    for (int i = 0; i < 2; i++)
        cin >> temp[i];

    dcache = L1Hit;
    for (int i = 0; i < 2; i++)
        if (temp[i])
            dcache = i + L2Hit;

    cin.ignore(10, 'P');
    cin >> physreg_full;
    cin.ignore(10, 'L');
    cin.ignore(10, 'S');
    cin >> lsq_full;
    cin.ignore(10, 'L');
    cin >> ldq_full;
    cin.ignore(10, 'S');
    cin >> stq_full;

    cin >> internal
        >> mf
        >> first_branch_mpred
        >> last_branch_mpred
        >> taken
        >> invalid;

    cin >> free_reg;

    pending_free_regs.clear();

    int pending_free_reg;
    cin >> pending_free_reg;
    while (pending_free_reg != -1){
        pending_free_regs.push_back(pending_free_reg);
        cin >> pending_free_reg;
    }

    cachelines.clear();
    if (isload()){
        for (int i = 0; i < 4; i++){
            u_int64_t cacheline;
            cin >> cacheline;
            cachelines.push_back(cacheline);
        }
        int wakeup_num;
        cin >> wakeup_num;
        wakeup.clear();
        for (int i = 0; i < wakeup_num; ++i){
            int temp;
            cin >> temp;
            wakeup.push_back(temp);
        }


        int temp;
        cin >> temp;
        int counter_d = 0;
        while(temp != -1){
            ++counter_d;
            data_deps.insert(temp);
            cin >> temp;
        }

        cin >> temp;
        while (temp != -1){
            addr_deps.insert(temp);
            cin >> temp;
        }
        {
            wakeup_id.clear();
            int wakeup_id_num;
            cin >> wakeup_id_num;
            for (int i = 0; i < wakeup_id_num; ++i){
                int temp;
                cin >> temp;
                wakeup_id.push_back(temp);
            }
        }

        cin >> who_wakeup
            >> rob_id;
    }
    cin >> physaddr;

    // itlb miss event
    bool itlb_miss_p= false;
    for (int i = 0; i < tlb_walk_level; ++i){
        cin >> itlb_miss[i].first;
        cin >> itlb_miss[i].second;
        itlb_miss_p = itlb_miss_p || itlb_miss[i].first;
    }
    assert (itlb_miss_p || itlb_delay == 0 || itlb_delay == 1);

    if (isload() || isstore()){
        bool dtlb_miss_p = false;
        for (int i = 0; i < tlb_walk_level; ++i){
            cin >> dtlb_miss[i].first;
            cin >> dtlb_miss[i].second;
            dtlb_miss_p = dtlb_miss_p || dtlb_miss[i].first;
        }
        assert (dtlb_miss_p || dtlb_delay == 0);
    }

    //  return cin;
    //

    if (cin.good())
        return true;
    else
        return false;
}


ostream &operator <<(ostream &os, _trace_info &tr){
    return tr.print(os);
}

ostream &_trace_info::print(ostream &os){
    os << som, eom, redispatch, opcode,
        reg_rd, reg_ra, reg_rb, reg_rc, reg_rs, reg_mf,
        fetch, fq_in_delay, itlb_delay, icache_delay,
        rename_try_delay, rename_rob_suf_cond_delay,
        rename_physreg_suf_cond_delay, rename_ldq_suf_cond_delay,
        rename_stq_suf_cond_delay, rename_lsq_suf_cond_delay, rename_delay,
        iq_full_delay, dispatch_delay;

    if (redispatch)
        os, redispatch_delay;

    if (isload() || isstore()){
        os, addrgen_ready_delay, addrgen_delay, dtlb_delay;
    }

    os, ready_delay, issue_delay,
        complete_delay, ready_to_commit_delay,
        commit_delay,
        store_dcache_stall,
        exception_stall,
        smc_stall,
        memlocked;

    os, 'B', barrier,
        "ST", stop,
        "INT", interrupt,
        'F', fu_lat,
        'I', icache,
        'D', dcache,
        'P', physreg_full,
        "LS", lsq_full,
        "L" , ldq_full,
        "S" , stq_full,
        internal, mf, first_branch_mpred, last_branch_mpred, taken, invalid;

    os, free_reg;

    if (isload()){
        os << " ";
        copy(cachelines.begin(), cachelines.end(), ostream_iterator<u_int64_t> (os, " "));
        // for (int i = 0; i < 3; i++)
        //   cout, cachelines[i];
        os << wakeup.size() << " ";
        copy(wakeup.begin(), wakeup.end(), ostream_iterator<int> (os, " "));
        // data dependnency
        copy(data_deps.begin(), data_deps.end(), ostream_iterator<int> (os, " "));
        os << -1 << " ";
        copy(addr_deps.begin(), addr_deps.end(), ostream_iterator<int> (os, " "));
        os << -1 << " ";
        os << wakeup_id.size() << " ";
        copy(wakeup_id.begin(), wakeup_id.end(), ostream_iterator<int> (os, " "));
        os << who_wakeup << " " << rob_id << '\n';
    }
    else
        os << '\n';

    return os;
}

bool _trace_info::isload(){
    string ref("ld");
    string ref2("ldx");
    return !opcode.compare(ref) || !opcode.compare(ref2);
}

bool _trace_info::isstore(){
    string ref("st");
    return !opcode.compare(ref);
}

bool _trace_info::isbrp(){
    string ref("brp");
    return !opcode.compare(ref);
}

bool _trace_info::isbr(){
    string ref("br");
    string ref2("bru");
    string ref3("jmp");
    return !opcode.compare(ref) || !opcode.compare(ref2) ||
        !opcode.compare(ref3);
}

u_int64_t _trace_info::fetch_cycle(){
    return fetch;
}
u_int64_t _trace_info::fq_in_cycle(){
    return fetch_cycle() + fq_in_delay;
}
u_int64_t _trace_info::itlb_cycle(){
    return fq_in_cycle() + itlb_delay;
}
u_int64_t _trace_info::icache_cycle(){
    return itlb_cycle() + icache_delay;
}
u_int64_t _trace_info::rename_cycle(){
    return icache_cycle() + rename_try_delay +
        rename_rob_suf_cond_delay;
}
u_int64_t _trace_info::rename_done_cycle(){
    return rename_cycle() + rename_physreg_suf_cond_delay +rename_ldq_suf_cond_delay +
        rename_stq_suf_cond_delay + rename_lsq_suf_cond_delay
        + rename_delay;
}
u_int64_t _trace_info::dispatch_cycle(){
    u_int64_t temp = rename_done_cycle() + iq_full_delay + dispatch_delay;
    if (redispatch)
        temp += redispatch_delay;
    return temp;
}
u_int64_t _trace_info::addrready_cycle(){
    assert(isload() || isstore());
    return dispatch_cycle() + addrgen_ready_delay;
}

u_int64_t _trace_info::addrgen_cycle(){
    assert(isload() || isstore());
    return addrready_cycle() + addrgen_delay;
}
u_int64_t _trace_info::dtlb_cycle(){
    assert(isload() || isstore());
    return addrgen_cycle() + dtlb_delay;
}

u_int64_t _trace_info::ready_cycle(){
    u_int64_t temp;
    if (isload() || isstore()){
        temp = dtlb_cycle();
    }
    else{
        temp = dispatch_cycle();
    }
    return temp + ready_delay;
}
u_int64_t _trace_info::issue_cycle(){
    return ready_cycle() + issue_delay;
}
u_int64_t _trace_info::complete_cycle(){
    return issue_cycle() + complete_delay;
}

//_penalty
ostream &operator << (ostream &os, _penalty &p){
    os << "<" << p.type << ':' << p.weight << "> ";
    return os;
}

//edge
bool edge::typecheck(int type){
    for (int i = 0; i != penalty_list.end(); i++){
        if (penalty_list[i].type == type){
            return true;
        }
    }
    return false;
}

int edge::get_penalty_weight(int type){
    for (int i = 0; i != penalty_list.end(); i++){
        if (penalty_list[i].type == type){
            return penalty_list[i].weight;
        }
    }
    return 0;
}

void edge::add_penalty(int type, int weight){
    //  assert (weight >= 0);
    penalty_list.insert(_penalty(type, weight));
}

bool edge::ch_weight(int type, int weight, int ch_type){
    bool found = false;
    for (int i = 0; i != penalty_list.end(); i++){
        _penalty &target = penalty_list[i];
        if (target.type == type){
            target.weight = weight;
            if (ch_type != -1)
                target.type = ch_type;
            found = true;
        }
    }
    return found;
}

bool edge::ch_weight_inc(int type, int diff, int default_weight, int ch_type){
    bool found = false;
    for (int i = 0; i != penalty_list.end(); i++){
        _penalty &target = penalty_list[i];
        if (target.type == type){
            int tmp = target.weight + diff;
            tmp = tmp >= 0 ? tmp : default_weight;
            target.weight = tmp;
            if (ch_type != -1)
                target.type = ch_type;
            found = true;
        }
    }
    return found;
}

int edge::weight(){
    int sum = 0;
    for (int i = 0; i != penalty_list.end(); i++){
        sum += penalty_list[i].weight;
    }
    return sum;
}

ostream & edge::print(ostream &os){
    string pad_s(pad, ' ');
    os <<  pad_s << "{ " << target_distance << " ";
    pad += 2;
    for (int i = 0; i != penalty_list.end(); i++)
        os << penalty_list[i];
    pad -= 2;
    os << "}" << '\n';
    return os;
}

ostream &operator << (ostream &os, edge &e){
    return e.print(os);
}

//state
u_int64_t state::count = 0;

void state::add_edge(edge &l){
    edges.insert(l);
}

void state::del_edge(int i){
    edges.erase(i);
}

ostream & state::print(ostream &os){
    //  os << "Cycles : " << cycle;
    string pad_s(pad, ' ');
    os << pad_s << "<< " <<  idx << ' ' << type << '\n';
    pad += 2;
    for (int i = 0; i != edges.end(); i++)
        os << edges[i];
    pad -= 2;
    os << pad_s << ">>" << '\n';
    return os;
}

ostream &operator << (ostream &os, state &s){
    return s.print(os);
}

// Mapping table for state idx;
const int uop::map_type1[StateNum] = {0, 1, 2, 3, 4, 0, 0, 0,
                                      5, 6, 7, 8, 9}; // For others
const int uop::map_type2[StateNum] = {0, 1, 2, 3, 4, 5, 6, 7,
                                      8, 9, 10, 11, 12}; // For ld/st/
char uop::ss_to_p[StateNum][StateNum];

// uop Class Function Definition
int uop::count = 0;

uop *uop::uop_buffer;
int uop::uop_buffer_size;

bool uop::first = true;

// Initializing states' pair to penalty type mapping table
// FetchPenalty ==> //InorderFetch, FetchWidthLimit,
// BranchMissPenalty ==> //Branch miss delays instruction fetch
// ITLBMissPenalty ==> // ITLB miss
// ICacheMissPenalty ==> // ICache miss
// RenamePenalty ==> // Rename pipeline length 1
// InorderRenamePenalty ==>
// ResourceShortagePenalty ==> Physical Register, LDQ, LSQ, STQ
// DispatchPenalty ==> // IQ shortage, Redispatch
// InorderDispatchPenalty ==> // InorderDispatch
// ReadyPipelinePenalty ==> // Dispatch to Ready pipeline length : 0
// TransferPenalty == > // Data dependency : ra, rb, rc, rs register | ra, rb for ld/st
// FUShortagePenalty ==> // FU Shortage
// FUPenalty ==> // Funtional unit latency and D$ miss
// CachelineSharingPenalty ==> // Load's cacheline sharing
// UOPCommitPenalty ==> // uop can commit when all uops in macro op become ready to commit
// CommitPenalty ==> InorderCommit, CommitWidthLimit
// DTLBMissPenalty ==> DTLB miss

#define make_three(a, b, c) make_pair(make_pair((int) a, (int) b), (int) c)

void uop::init_map(){
    for (int i = 0; i < StateNum; ++i)
        for (int j = 0; j < StateNum; ++j)
            ss_to_p[i][j] = -1;

    ss_to_p[Fetch][ICache] = FetchPenalty;
    ss_to_p[Fetch][Issue] = BranchMissPenalty;
    ss_to_p[Fetch][Rename] = FQLimitPenalty;
    ss_to_p[ITLB][Fetch] = ITLBMissPenalty;
    ss_to_p[ICache][ITLB] = ICacheMissPenalty;
    ss_to_p[Rename][ICache] = RenamePenalty;
    ss_to_p[Rename][Rename] = InorderRenamePenalty;
    ss_to_p[Rename][Commit] = ResourceShortagePenalty;
    ss_to_p[Dispatch][Rename] = DispatchPenalty;
    ss_to_p[Dispatch][Dispatch] = InorderDispatchPenalty;
    ss_to_p[Ready][Dispatch] = ReadyPipelinePenalty;
    ss_to_p[Dispatch][Issue] = IQPenalty;
    ss_to_p[Ready][Complete] = TransferPenalty;
    ss_to_p[Ready][AddrGen] = MemAddrPenalty;
    ss_to_p[Issue][Ready] = FUShortagePenalty;
    ss_to_p[Issue][Issue] = MemDataDepPenalty;
    ss_to_p[AddrReady][Dispatch] = ReadyPipelinePenalty;
    ss_to_p[AddrReady][Complete] = TransferPenalty;
    ss_to_p[AddrGen][AddrReady] = FUShortagePenalty;
    ss_to_p[DTLB][AddrGen] = DTLBMissPenalty;
    ss_to_p[Ready][DTLB] = ReadyPipelinePenalty;
    ss_to_p[Complete][Issue] = FUPenalty;
    ss_to_p[Complete][Complete] = CachelineSharingPenalty;
    ss_to_p[ReadyToCommit][Issue] = UOPCommitPenalty;
    ss_to_p[ReadyToCommit][Commit] = CommitPenalty;
    ss_to_p[ReadyToCommit][Complete] = UOPCommitPenalty;
    ss_to_p[Commit][ReadyToCommit] = CommitBlockedPenalty;
//    ss_to_p[Commit][] = ;
}


u_int64_t uop::add_edge(u_int64_t from_uop_id, int from_state, int to_state, int aux)
{
    //Find distance
    uop &from_buffer = access_buffer(from_uop_id);
    int distance = from_buffer.access_state(from_state).get_idx() - access_state(to_state).get_idx();
    //Calculate penalty
    int type = ss_to_p[from_state][to_state];
    assert(type != -1);
    int idx_diff = from_uop_id - id;
    edge l;

    l.set_distance(distance);

    _trace_info &from_tr = access_buffer(from_uop_id).trace_info;
    bool same = from_uop_id == id;
    bool inorder = idx_diff == 1;

    u_int64_t to_state_cycle = get_cycle(to_state);

    switch(type){
    case FetchPenalty:{
        if (inorder){
            u_int64_t backup = to_state_cycle;
            to_state_cycle = icache_cycle();
            //Redispatch temporal branch miss
            if (trace_info.isbrp()){
                l.add_penalty(BRP, from_tr.fetch_cycle() - to_state_cycle);
            }
            else{
                int bias = 0;
                if (trace_info.taken){
                    l.add_penalty(InorderFetch, 1);
                    bias = 1;
                }
                else
                    l.add_penalty(InorderFetch, 0);

                if (trace_info.first_branch_mpred && !trace_info.last_branch_mpred){
                    int weight =  from_tr.fetch_cycle() - to_state_cycle  - bias;
                    l.add_penalty(RedispatchBranchMiss, weight);
                }

                int weight = from_tr.fetch_cycle() - to_state_cycle - l.weight();
                if (trace_info.interrupt){
                    l.add_penalty(InterruptFetchBlocked, weight);
                }
            }
            to_state_cycle = backup;
        }
        else{
            //FetchWidth
            l.add_penalty(FetchWidthLimit, 1);
        }
        break;
    }
    case FQLimitPenalty:{
        l.add_penalty(FQShortage, 0);
        break;
    }
    case BranchMissPenalty:{
        l.add_penalty(BranchMiss, 0);
        break;
    }
    case ITLBMissPenalty:{
        assert (same);
        if (!from_tr.itlb_delay)
            l.add_penalty(ITLBHit, 0);
        else{
            int itlb_lat = 0;
            for (int i = 0; i < tlb_walk_level; ++i){
                int delay = from_tr.itlb_miss[i].first;
                int miss_event = from_tr.itlb_miss[i].second;
                int type;
                const int ibuffer_flag = 0x01;
                const int l1miss_flag = 0x02;
                const int l2miss_flag = 0x04;
                if (miss_event & l2miss_flag)
                    type = ITLB_MemHit;
                else if (miss_event & l1miss_flag)
                    type = ITLB_L2Hit;
                else if (miss_event & ibuffer_flag)
                    type = ITLB_L1Hit;
                else
                    type = ITLB_IBufferHit;
                l.add_penalty(type, delay);
                itlb_lat += delay;
            }
            //assert(from_tr.itlb_delay == itlb_lat);
            l.add_penalty(ITLBMiss, from_tr.itlb_delay - itlb_lat);
        }
        break;
    }
    case ICacheMissPenalty:{
        assert (same);
        //delay due to icache blocked
        int penalty_type;
        switch(from_tr.icache){
        case L1Hit:
            penalty_type = ICacheL1Hit;
            break;
        case L2Hit:
            penalty_type = ICacheL2Hit;
            break;
        case L2Miss:
            penalty_type = ICacheMemHit;
            break;
        default :
            assert(0);
            break;
        }
        l.add_penalty(penalty_type, from_tr.icache_delay);
        break;
    }
    case RenamePenalty:{
        assert (same);
        l.add_penalty(RenameBaseDelay, 1);
        break;
    }
    case InorderRenamePenalty:{
        assert(!same);
        if (inorder){
            l.add_penalty(InorderFrontend, 0);
        }
        else{
            l.add_penalty(FrontendWidthLimit, 1);
        }
        // Physical register shoratage dependency
        if (aux == 1){
            l.add_penalty(PhysregShortage, 1);
        }
        break;
    }
    case ResourceShortagePenalty:{
        assert(!same);
        switch(aux){
        case 0:
            l.add_penalty(ROBShortage, 0);
            break;
        case 1:
            l.add_penalty(PhysregShortage, 0);
            break;
        case 2:
            l.add_penalty(LDQShortage, 0);
            break;
        case 3:
            l.add_penalty(STQShortage, 0);
            break;
        case 4:
            l.add_penalty(LSQShortage, 0);
            break;
        default:
            assert(0);
            break;
        }
        break;
    }
    case DispatchPenalty:{
        assert (same);
        l.add_penalty(FrontendDelay, 6);
        //l.add_penalty(IQShortage, from_tr.iq_full_delay);
        if (trace_info.redispatch){
            l.add_penalty(Redispatch, from_tr.redispatch_delay);
            l.add_penalty(FrontendDelay, from_tr.dispatch_delay - 6);
        }
        break;
    }
    case InorderDispatchPenalty:{
        if (inorder)
            l.add_penalty(InorderDispatch, 0);
        else{
            l.add_penalty(DispatchWidthLimit, 1);
        }
        break;
    }
    case IQPenalty:{
        l.add_penalty(IQShortage, 0);
        break;
    }
    case TransferPenalty:{
        l.add_penalty(Transfer, 0);
        break;
    }
    case MemAddrPenalty: {
        if (same)
            l.add_penalty(MemAddr, 0);
        else
            l.add_penalty(MemAddrWaiting, 0);
        break;
    }
    case FUShortagePenalty:{
        assert (same);
        l.add_penalty(IssueBaseDelay, 0);
        //Issue
        if (from_state == Issue){
            int shortage_type = 0;
            switch (trace_info.alutype){
            case 0:
                shortage_type = FUBaseShortage;
                break;
            case 1:
                shortage_type = FUMULShortage;
                break;
            case 2:
                shortage_type = FUDIVShortage;
                break;
            case 3:
                shortage_type = FUFPADDShortage;
                break;
            case 4:
                shortage_type = FUFPSUBShortage;
                break;
            case 5:
                shortage_type = FUFPMULShortage;
                break;
            case 6:
                shortage_type = FUFPDIVShortage;
                break;
            case 7:
                shortage_type = FUFPShortage;
                break;
            case 8:
                shortage_type = FUFPCVTShortage;
                break;
            }
            l.add_penalty(shortage_type, from_tr.issue_delay);
        }
        else if (from_state == AddrGen){
            l.add_penalty(FUAddrShortage, from_tr.addrgen_delay);
        }
        break;
    }
    case ReadyPipelinePenalty:{
        if (to_state == DTLB){
            if (same)
                l.add_penalty(ReadyBaseDelay, 0);
            else
                l.add_penalty(MemAddrWaiting, 0);
        }
        else{
            assert(same);
            l.add_penalty(ReadyBaseDelay, 1);
        }
        break;
    }
    case FUPenalty:{
        assert (same);
        if (trace_info.complete_delay)
        {
            int fu_lat = trace_info.fu_lat;
            if (!trace_info.isload())
            {
                switch (trace_info.alutype)
                {
                case 0:
                    l.add_penalty(FUBaseLat, fu_lat);
                    break;
                case 1:
                    l.add_penalty(ALUIntMul, fu_lat);
                    break;
                case 2:
                    l.add_penalty(ALUIntDiv, fu_lat);
                    break;
                case 3:
                    l.add_penalty(ALUFPAdd, fu_lat);
                    break;
                case 4:
                    l.add_penalty(ALUFPSub, fu_lat);
                    break;
                case 5:
                    l.add_penalty(ALUFPMul, fu_lat);
                    break;
                case 6:
                    l.add_penalty(ALUFPDiv, fu_lat);
                    break;
                case 7:
                    l.add_penalty(ALUFP, fu_lat);
                    break;
                case 8:
                    l.add_penalty(ALUFPCvt, fu_lat);
                    break;
                }
            }
            int complete_delay = trace_info.complete_delay;
            if (!(!(complete_delay > fu_lat) || trace_info.isload() || trace_info.ismf()))
            {
                switch (trace_info.alutype)
                {
                case 0:
                    l.ch_weight(FUBaseLat, complete_delay);
                    break;
                case 1:
                    l.ch_weight(ALUIntMul, complete_delay);
                    break;
                case 2:
                    l.ch_weight(ALUIntDiv, complete_delay);
                    break;
                case 3:
                    l.ch_weight(ALUFPAdd, complete_delay);
                    break;
                case 4:
                    l.ch_weight(ALUFPSub, complete_delay);
                    break;
                case 5:
                    l.ch_weight(ALUFPMul, complete_delay);
                    break;
                case 6:
                    l.ch_weight(ALUFPDiv, complete_delay);
                    break;
                case 7:
                    l.ch_weight(ALUFP, complete_delay);
                    break;
                case 8:
                    l.ch_weight(ALUFPCvt, complete_delay);
                    break;
                }
            }

            if (trace_info.ismf())
            {
                l.add_penalty(MfLat, complete_delay - l.weight());
            }

            if (trace_info.isload())
            {
                int delay = complete_delay;

                switch (trace_info.dcache)
                {
                case L1Hit:
                    if (trace_info.who_wakeup == -1){
                        l.add_penalty(DCacheL1Hit, delay);
                        //assert (delay <= default_l1d_lat);
                    }
                    else {
                        //Backward Edge
                        // int temp = delay;
                        // while (temp > 0){
                        //     int weight = temp > default_l1d_lat ? default_l1d_lat : temp;
                        //     l.add_penalty(Back_DCacheL1Hit, weight);
                        //     temp -= weight;
                        // }
                        l.add_penalty(Back_DCacheL1Hit, delay);
                        //cerr << "L1D "<< count << ' ' << delay << '\n';
                    }
                    break;
                case L2Hit:
                    if (trace_info.who_wakeup == -1){
                        l.add_penalty(DCacheL2Hit, delay);
                        //assert(delay <= (default_l1d_lat + default_l2d_lat));
                    }
                    else{
                        //Backward Edge
                        // int temp = delay;
                        // while (temp > 0){
                        //     int weight = temp > default_l2d_lat ? default_l2d_lat : temp;
                        //     l.add_penalty(Back_DCacheL2Hit, weight);
                        //     temp -= weight;
                        // }
                        l.add_penalty(Back_DCacheL2Hit, delay);
                        //cerr << "L2D "<< count << ' ' << delay << '\n';
                    }
                    break;
                case L2Miss:
                    if (trace_info.who_wakeup == -1){
                        l.add_penalty(DCacheMemHit, delay);
                        //assert(delay <= default_l1d_lat + default_l2d_lat + default_mem_lat);
                    }
                    else {
                        //Backward Edge
                        // int temp = delay;
                        // while (temp > 0){
                        //     int weight = temp > default_mem_lat ? default_mem_lat : temp;
                        //     l.add_penalty(Back_DCacheMemHit, weight);
                        //     temp -= weight;
                        //
                        l.add_penalty(Back_DCacheMemHit, delay);
                            //cerr << "MEM "<< count << ' ' << delay << '\n';
                    }
                    break;
                default:
                    l.add_penalty(LoadBaseLat, 1);
                    //	  cerr << "Hey";
                    //	  assert(0);
                    break;
                }
            }
        }
        else
        {
            l.add_penalty(FUBaseLat, 0);
        }
        break;
    }
    case CachelineSharingPenalty:{
        //u_int64_t penalty = from_tr.complete_cycle() - to_state_cycle;
        u_int64_t backup = to_state_cycle;
        to_state_cycle = complete_cycle();
        u_int64_t penalty = from_tr.complete_cycle() - to_state_cycle;
        // Cache Miss Info
        int cache_miss_type = trace_info.dcache;
        switch(aux){
        case 0:
            // H_L1Cacheline
            switch (cache_miss_type){
            case L1Hit:
                type = L1Hit_H_L1CachelineSharing;
                break;
            case L2Hit:
                type = L2Hit_H_L1CachelineSharing;
                break;
            case L2Miss:
                type = L2Miss_H_L1CachelineSharing;
                break;
            default:
                assert(0);
                break;
            }
        case 1:
            // L_L1Cacheline
            switch (cache_miss_type){
            case L1Hit:
                type = L1Hit_L_L1CachelineSharing;
                break;
            case L2Hit:
                type = L2Hit_L_L1CachelineSharing;
                break;
            case L2Miss:
                type = L2Miss_L_L1CachelineSharing;
                break;
            default:
                assert(0);
                break;
            }
            break;
        case 2:
            switch (cache_miss_type){
            case L1Hit:
                assert(0);
            case L2Hit:
                type = L2Hit_L2CachelineSharing;
                break;
            case L2Miss:
                type = L2Miss_L2CachelineSharing;
                break;
            default:
                assert(0);
                break;
            }
            break;
        case 3:
            switch (cache_miss_type){
            case L1Hit:
            case L2Hit:
                assert(0);
                break;
            case L2Miss:
                type = L2Miss_BankSharing;
                break;
            default:
                assert(0);
                break;
            }
            break;
        default:
            assert(0);
        }
        to_state_cycle = backup;
        l.add_penalty(type, penalty);

        // if (penalty > 200){
        //   cerr <<  id << " " << trace_info << '\n';
        //   cerr <<  from_buffer.id << " " << from_tr << '\n';
        // }
        // cerr << "Cache " << penalty << '\n';
        // copy(trace_info.cachelines.begin(), trace_info.cachelines.end(), ostream_iterator<u_int64_t>(cerr, " "));
        // cerr << '\n';
        // copy(from_tr.cachelines.begin(), from_tr.cachelines.end(), ostream_iterator<u_int64_t>(cerr, " "));
        // cerr << '\n';
        break;
    }
    case MemDataDepPenalty:{
        l.add_penalty(MemDataDep, 0);
        break;
    }
    case UOPCommitPenalty:{
        if (trace_info.ismf() && !same){
            l.add_penalty(CommitBaseDelay, 1);
        }
        else{
            l.add_penalty(CommitBaseDelay, trace_info.ready_to_commit_delay + 1);
        }
        break;
    }
    case CommitPenalty:{
        if (inorder){
            l.add_penalty(InorderCommit, 0);
            if (trace_info.interrupt){
                l.add_penalty(CommitInterrupt, 1);
            }
            if (trace_info.barrier){
                l.add_penalty(CommitBarrier, 1);
            }
            if (trace_info.stop){
                l.add_penalty(CommitStop, 1);
            }
        }
        else {
            l.add_penalty(CommitWidthLimit, 1);
        }
        break;
    }
    case DTLBMissPenalty:{
        assert (same);
        if (!from_tr.dtlb_delay)
            l.add_penalty(DTLBHit, from_tr.dtlb_delay);
        else{
            int dtlb_lat = 0;
            for (int i = 0; i < tlb_walk_level; ++i){
                int delay = from_tr.dtlb_miss[i].first;
                int miss_event = from_tr.dtlb_miss[i].second;
                int type;
                const int l1miss_flag = 0x01;
                const int l2miss_flag = 0x02;
                if (miss_event & l2miss_flag)
                    type = DTLB_MemHit;
                else if (miss_event & l1miss_flag)
                    type = DTLB_L2Hit;
                else
                type = DTLB_L1Hit;
                dtlb_lat += delay;
                l.add_penalty(type, delay);
            }
            assert(from_tr.dtlb_delay == dtlb_lat);
        }
        break;
    }
    case CommitBlockedPenalty:{
        assert(same);
        l.add_penalty(CommitBaseDelay, 0);
        if (trace_info.store_dcache_stall){
            assert(isstore());
            l.add_penalty(DcacheStall, trace_info.store_dcache_stall);
        }
        if (trace_info.exception_stall){
            l.add_penalty(Exception, trace_info.exception_stall);
        }
        if (trace_info.smc_stall){
            l.add_penalty(SMC, trace_info.smc_stall);
        }
        if (trace_info.memlocked){
            l.add_penalty(MemLocked, trace_info.memlocked);
        }
        break;
    }
    default:
        assert (0);
        break;
    }

    assert(l.weight() >= 0);
    access_state(to_state).add_edge(l);
    u_int64_t result =  l.weight() + to_state_cycle;
    return result;
}

int uop::get_num_of_states(){
    return states_num;
}

int uop::get_state_idx(int state){
    //input state type should be appropriate for its owner uop type.
    if (isload() || isstore())
        return map_type2[state] + 1;
    else
        return map_type1[state] + 1;
}

u_int64_t uop::get_cycle(int state)
{
    return states[state_map[state]].get_cycle();
}

int uop::get_regid(int reg){
    switch(reg){
    case RA:
        return trace_info.reg_ra;
        break;
    case RB:
        return trace_info.reg_rb;
        break;
    case RC:
        return trace_info.reg_rc;
        break;
    case RD:
        return trace_info.reg_rd;
        break;
    case RS:
        return trace_info.reg_rs;
        break;
    case MF:
        return trace_info.reg_mf;
        break;
    default:
        assert(0);
        break;
    }
}

bool uop::init(){
    do{
        if (!trace_info.load())
            return false;
    }
    while (uop::first && !trace_info.som);

    uop::first = false;

    id = count++;
    this->mop = macroOp::add_uop(this);

    if (isload() || isstore()){
        states_num = StateNum;
        state_map = map_type2;
    }
    else{
        states_num = state_num_;
        state_map = map_type1;
    }

    for (int i = 0; i < StateNum; i++){
        states[i].reset();
    }

    return true;
}

ostream &uop::print(ostream &os){
    //Fetch to Dispatch
    pad += 2;
    for (int i = Fetch; i <= Dispatch; i++){
        os << access_state(i);
    }
    //Mem
    if (isload() || isstore()){
        for (int i = AddrReady; i <= DTLB; i++){
            os << access_state(i);
        }
    }
    for (int i = Ready; i <= Complete; i++){
        os << access_state(i);
    }
    pad -= 2;
    return os;
}

ostream &uop::print_commit(ostream &os){
    pad += 2;
    for (int i = ReadyToCommit; i <= Commit; i++){
        os << access_state(i);
    }
    pad -= 2;
    return os;
}

ostream &operator << (ostream &os, uop &inst){
    return inst.print(os);
}


// macroOp Class Function Definition
static_queue<macroOp, uop_buffer_size> macroOp::buffer;
map<int, uop*> *macroOp::renaming_table;

void macroOp::set_renaming_table(map<int, uop*> *renaming_table_) {
    renaming_table = renaming_table_;
}

macroOp* macroOp::add_uop(uop *inst){
    macroOp &last = buffer.empty() ? alloc() : buffer.back();

    if (last.isvalid()){
        macroOp &last = alloc();
        last.init();
        int id = inst->get_id();
        //    cerr << id << endl;
        last.som_id = id;
        last.uop_buffer.push_back(inst);
        if (inst->iseom()){
            last.eom_id = id;
            last.valid = true;
        }
    }
    else{
        int id = inst->get_id();
        //    cerr << id << endl;
        if (inst->issom()){
            last.som_id = id;
        }

        if (inst->iseom()){
            last.eom_id = id;
            last.valid = true;
        }
        last.uop_buffer.push_back(inst);
    }

    if (inst->get_id() % 100000 == 0){
        cerr << "[Progress(#insns)]  " << inst->get_id() << endl;
    }

    return &last;
}

bool macroOp::is_this_uop_in(u_int64_t uop_id){
    if (valid)
        return (uop_id <= eom_id) && (uop_id >= som_id);
    else
        return (uop_id >= som_id);
}

void macroOp::clear(){
    //Clear renaming table entry
    vector<uop *>::iterator uop_it;
    for (uop_it = uop_buffer.begin(); uop_it != uop_buffer.end(); uop_it++){
        map<int, uop*>::iterator target = renaming_table->find((*uop_it)->get_regid(RD));
        if (target != renaming_table->end()){
            if (target->second == *uop_it)
                renaming_table->erase(target);
        }
    }
}

ostream & macroOp::print(ostream &os){
    int end = uop_buffer.size();
    // cout << "[\n";
    // pad += 2;
    for (int i = 0; i < end; i++){
        os << *(uop_buffer[i]);
    }

    for (int i = 0; i < end; i++){
        uop_buffer[i]->print_commit(os);
    }
    // pad -= 2;
    // cout << "]\n";
    return os;
}

ostream & operator << (ostream &os, macroOp &mop){
    return mop.print(os);
}
