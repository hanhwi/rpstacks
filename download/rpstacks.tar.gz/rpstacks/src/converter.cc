// Copyright 2014 Hanhwi Jang, Jaewon Lee, Jae-Eon Jo, and Jangwoo Kim

// Redistribution and  use in  source and binary  forms, with  or without
// modification, are permitted provided that the following conditions are
// met:

// 1.  Redistributions of  source code  must retain  the above  copyright
// notice, this list of conditions and the following disclaimer.

// 2. Redistributions in  binary form must reproduce  the above copyright
// notice, this  list of conditions  and the following disclaimer  in the
// documentation and/or other materials provided with the distribution.

// 3.  Neither the  name of  the copyright  holder nor  the names  of its
// contributors may be  used to endorse or promote  products derived from
// this software without specific prior written permission.

// THIS SOFTWARE  IS PROVIDED BY  THE COPYRIGHT HOLDERS  AND CONTRIBUTORS
// "AS  IS" AND  ANY EXPRESS  OR IMPLIED  WARRANTIES, INCLUDING,  BUT NOT
// LIMITED TO, THE IMPLIED WARRANTIES  OF MERCHANTABILITY AND FITNESS FOR
// A PARTICULAR PURPOSE  ARE DISCLAIMED. IN NO EVENT  SHALL THE COPYRIGHT
// HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
// SPECIAL,  EXEMPLARY,  OR  CONSEQUENTIAL DAMAGES  (INCLUDING,  BUT  NOT
// LIMITED TO, PROCUREMENT OF SUBSTITUTE  GOODS OR SERVICES; LOSS OF USE,
// DATA, OR PROFITS; OR BUSINESS  INTERRUPTION) HOWEVER CAUSED AND ON ANY
// THEORY OF  LIABILITY, WHETHER IN  CONTRACT, STRICT LIABILITY,  OR TORT
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN  ANY WAY OUT OF THE USE
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

#include "converter.hh"
#include "util.hh"
#include <fstream>

using namespace std;

int converter::idx = 0;

converter::converter(int threshold, int interval, char *ofprefix)
    : threshold(threshold), interval(interval)
{
    dynamic_threshold = false;

    if (threshold == -2){
        dynamic_threshold = true;
        threshold = 1000; // Default value
    }

    if (ofprefix != NULL)
        this->ofprefix = ofprefix;
}

bool converter::load(){
    if (!cin)
        return false;

    state &cur_state = buffer.alloc();
    stat &cur_stat = stat_buffer.alloc();
    vector<cp> &cur_cps = cp_buffer.alloc();

    cur_state.init();
    cur_stat.init();
    cur_cps.clear();

    cin.ignore(10, '<');
    cin.ignore(10, '<');
    u_int64_t idx;
    cin >> idx;
    int type;
    cin >> type;
    cur_state.set_type(type);
    cin.ignore(10, '{');

    while(cin.good()){
        edge l;
        int target;
        cin >> target;
        l.set_distance(target);
        cin.ignore(10, '<');
        while (1)
        {
            int type;
            int weight;
            cin >> type;
            cin.ignore(10, ':');
            cin >> weight;
            l.add_penalty(type, weight);
            cin.ignore(10, '>');
            char ch;
            cin >> ch;
            if (ch == '}')
                break;
            else if (ch != '<')
                assert(0);
        }
        cur_state.add_edge(l);
        char ch;
        cin >> ch;
        if (ch == '>')
            break;
        else if (ch != '{')
            assert(0);
    }
    cin.ignore(10, '>');

    //  cerr << cur_state;
    return cin;
}

void converter::start(bool ideal_itlb, bool ideal_dtlb, bool ideal_brpred, int l1d_lat,
                      int l2i_lat, int l2d_lat, int mem_lat, int long_lat,
                      int fadd_lat, int fmul_lat, int div_lat, int mul_lat,
                      bool perfect_l1i, bool perfect_l1d, bool perfect_l2i, bool perfect_l2d,
                      int weight_percent, int entry_percent)
{
    u_int64_t start;

    bool ch_l1d_lat = l1d_lat != -1;
    bool ch_l2i_lat = l2i_lat != -1;
    bool ch_l2d_lat = l2d_lat != -1;
    bool ch_mem_lat = mem_lat != -1;

    int default_l1i_lat = 2;
    int default_l1d_lat = 4;
    int default_l2i_lat = 12;
    int default_l2d_lat = 12;
    int default_mem_lat = 133;

    int l1i_lat = default_l1i_lat;

    int node_threshold = interval * 0.01;

    if (!ch_l1d_lat)
        l1d_lat = default_l1d_lat;
    if (!ch_l2i_lat)
        l2i_lat = default_l2i_lat;
    if (!ch_l2d_lat)
        l2d_lat = default_l2d_lat;
    if (!ch_mem_lat)
        mem_lat = default_mem_lat;

    //Read first instrcution's fetch cycle
    cin >> start;
    for (int i = 0; i < buffer_size; i++){
        if (!load())
            break;
    }

    buffer.front().set_cycle(start);
    //buffer.front().set_cycle(0);
    cp_buffer.front().push_back(cp());

    u_int64_t num_edges = 0;
    int merge_counter = 0;
    int state_counter = 0;
    // if som_checker is 0, the instruction is som
    // the checker increase and decrease at fetch node and commit node, respectively.
    int som_checker = 0;
    vector<cp> *prev_commit_cps = NULL;
    int fcount = 0;
    u_int64_t inst_count = 0;

    vector<cp> *prev_cps = NULL;

    while(buffer.size()){
        state &cur_state = buffer.front();
        stat &cur_stat = stat_buffer.front();
        vector<cp> &cur_cps = cp_buffer.front();

        if (cur_state.get_type() == Fetch){
            cur_stat.update_branch();
            if (ideal_brpred)
                cur_stat.merge_stat();
        }
        //    cerr << cur_state.get_idx() << " " << cur_cps.size() << '\n';

        int cur_cps_num = cur_cps.size();

        // Node optimizer!
        // This rocks!
        if(cur_cps_num > node_threshold && inst_count > 0.01*interval)
        {
            delete_redundancy(cur_cps, 1, 1, false);
            // Too low thresold
            if(cur_cps_num-cur_cps.size() == 0)
                node_threshold += 10;
            // Too high threshold
            else if(cur_cps_num-cur_cps.size() > node_threshold/2)
                node_threshold -= 5;
        }

        if (cur_state.get_type() == Fetch){
            ++merge_counter;
            ++inst_count;
        }

        // If merge_counter exceedes interval length,
        // and check the current instruction is som
        // it initializes all critical paths that belong to others
        if (cur_state.get_type() == Fetch)
            ++som_checker;
        else if (cur_state.get_type() == Commit){
            --som_checker;
            if (!som_checker)
                prev_commit_cps = &cur_cps;
        }

        if (interval && merge_counter > interval && som_checker == 1 && cur_state.get_type() == Fetch){
            // Print out previouse commit node's critical paths
            assert(prev_commit_cps == prev_cps);
            if (ofprefix.compare("") != 0){
                ofstream ofs;
                string ofname = ofprefix + "_" + itoa(fcount++);
                ofs.open(ofname.c_str());
                ofs << merge_counter - 1 << '\n';
                print_cps(ofs, *prev_commit_cps, weight_percent, entry_percent);
                ofs.close();
            }
            else{
                cout << merge_counter - 1 << '\n';
                print_cps(cout, *prev_commit_cps, weight_percent, entry_percent);
            }
            // Clear all critical paths
            cerr << "[ " << inst_count << " ] ";
            clear_cp_buffer();
            merge_counter = 1;
        }

        // Counter number of outcoming edges
        if (!cur_cps.empty())
            num_edges += cur_state.get_edges().end();

        int i = 0;
        while (i != cur_state.get_edges().end()){
            edge &cur_edge = cur_state.get_edges()[i];
            //Fetch negative edge
            {
                edge::penalty_list_t &penalty_list = cur_edge.get_penalties();
                for (int z = 0; z != penalty_list.end(); z++){
                    if (penalty_list[z].weight < 0)
                        penalty_list[z].weight = 0;
                }
            }

            assert(cur_edge.weight() >= 0);

            if (ideal_itlb){
                //ITLBMiss
                cur_edge.ch_weight(ITLBMiss, 0, ITLBHit)
                    || cur_edge.ch_weight(ITLB_IBufferHit, 0, ITLBHit)
                    || cur_edge.ch_weight(ITLB_L1Hit, 0, ITLBHit)
                    || cur_edge.ch_weight(ITLB_L2Hit, 0, ITLBHit)
                    || cur_edge.ch_weight(ITLB_MemHit, 0, ITLBHit);
            }
            if (ideal_dtlb){
                //DTLBMiss
                cur_edge.ch_weight(DTLBMiss, 0, DTLBHit)
                    || cur_edge.ch_weight(DTLB_L1Hit, 0, DTLBHit)
                    || cur_edge.ch_weight(DTLB_L2Hit, 0, DTLBHit)
                    || cur_edge.ch_weight(DTLB_MemHit, 0, DTLBHit);
            }
            if (ideal_brpred){
                // Change every branch miss prediction to correct prediction.
                // RedispatchBranchMiss
                cur_edge.ch_weight(RedispatchBranchMiss, 0);

                // BranchMiss
                if (cur_edge.typecheck(BranchMiss)){
                    cur_state.del_edge(i);
                    continue;
                }
            }

            if (perfect_l1i){
                // if l1_lat == 0, than it means l1 hit (2_cycle)
                // L2Miss, L2Hit . L1Hit
                cur_edge.ch_weight(ICacheL2Hit, 0, ICacheL1Hit)
                    || cur_edge.ch_weight(ICacheMemHit, 0, ICacheL1Hit)
                    || cur_edge.ch_weight(ITLB_L2Hit, 0, ITLB_L1Hit)
                    || cur_edge.ch_weight(ITLB_MemHit, 0, ITLB_L1Hit);
            }
            else if (perfect_l2i){
                // if L2_lat == 0, than it means l2 hit
                // L2Miss->L2Hit
                int l2_hit_lat = l1i_lat + l2i_lat;
                cur_edge.ch_weight(ICacheMemHit, l2_hit_lat, ICacheL2Hit)
                    || cur_edge.ch_weight(ITLB_MemHit, l2_hit_lat, ITLB_L2Hit);
            }
            else if (ch_l2i_lat || mem_lat){
                int l2_hit_lat = l1i_lat + l2i_lat;
                int mem_hit_lat = l1i_lat + l2i_lat + mem_lat;
                cur_edge.ch_weight(ICacheL2Hit, l2_hit_lat)
                    || cur_edge.ch_weight(ICacheMemHit, mem_hit_lat)
                    || cur_edge.ch_weight(ITLB_L2Hit, l2_hit_lat)
                    || cur_edge.ch_weight(ITLB_MemHit, mem_hit_lat);
            }

            if (perfect_l1d){
                // if l1_lat == 0, than it means l1 hit (2_cycle)
                // L2Miss, L2Hit . L1Hit
                cur_edge.ch_weight(DCacheL2Hit, l1d_lat - 1, DCacheL1Hit)
                    || cur_edge.ch_weight(DCacheMemHit, l1d_lat - 1, DCacheL1Hit)
                    || cur_edge.ch_weight(DTLB_L2Hit, l1d_lat, DTLB_L1Hit)
                    || cur_edge.ch_weight(DTLB_MemHit, l1d_lat, DTLB_L1Hit);

                if (cur_edge.typecheck(L2Hit_L2CachelineSharing)
                    || cur_edge.typecheck(L2Miss_L2CachelineSharing)
                    || cur_edge.typecheck(L2Miss_BankSharing)){
                    cur_state.del_edge(i);
                    continue;
                }
            }
            else if (perfect_l2d){
                cur_edge.ch_weight(DCacheMemHit, l1d_lat + l2d_lat - 1, DCacheL2Hit)
                    || cur_edge.ch_weight(L2Hit_L2CachelineSharing, l2d_lat + 1)
                    || cur_edge.ch_weight(L2Miss_L2CachelineSharing, l2d_lat + 1)
                    || cur_edge.ch_weight(DTLB_MemHit, l1d_lat + l2d_lat);

                if (cur_edge.typecheck(L2Miss_BankSharing)){
                    cur_state.del_edge(i);
                    continue;
                }

            }

            if (ch_l1d_lat)
            {
                cur_edge.ch_weight(DTLB_L1Hit, l1d_lat)
                    || cur_edge.ch_weight(L1Hit_L_L1CachelineSharing, l1d_lat)
                    || cur_edge.ch_weight(L2Hit_L_L1CachelineSharing, l1d_lat)
                    || cur_edge.ch_weight(L2Miss_L_L1CachelineSharing, l1d_lat)
                    || cur_edge.ch_weight(DCacheL1Hit, l1d_lat)
                    || cur_edge.ch_weight(Back_DCacheL1Hit, cur_edge.get_penalty_weight(Back_DCacheL1Hit) * l1d_lat / default_l1d_lat);
            }
            if (ch_l2d_lat){
                cur_edge.ch_weight (L2Hit_L2CachelineSharing, l2d_lat + 1)
                    || cur_edge.ch_weight (L2Miss_L2CachelineSharing, l2d_lat + 1)
                    || cur_edge.ch_weight (Back_DCacheL2Hit, cur_edge.get_penalty_weight(Back_DCacheL2Hit) * l2d_lat / default_l2d_lat);
            }
            if (ch_mem_lat){
                cur_edge.ch_weight (L2Miss_BankSharing, mem_lat)
                    || cur_edge.ch_weight (Back_DCacheMemHit, cur_edge.get_penalty_weight(Back_DCacheMemHit) * mem_lat / default_mem_lat);
            }

            if (ch_l1d_lat || ch_l2d_lat){
                cur_edge.ch_weight (DTLB_L2Hit, l1d_lat + l2d_lat)
                    || cur_edge.ch_weight (DTLB_L2Hit, l1d_lat + l2d_lat - 1)
                    || cur_edge.ch_weight (DCacheL2Hit, l1d_lat + l2d_lat - 1);
            }

            if (ch_l1d_lat || ch_l2d_lat || ch_mem_lat){
                cur_edge.ch_weight (DTLB_MemHit, l1d_lat + l2d_lat + mem_lat)
                    || cur_edge.ch_weight (DCacheMemHit, l1d_lat + l2d_lat + mem_lat - 1);
            }

            if (fadd_lat >= 0){
                cur_edge.ch_weight(ALUFPAdd, fadd_lat - 1)
                    || cur_edge.ch_weight(ALUFPSub, fadd_lat - 1);
            }
            if (fmul_lat >= 0){
                cur_edge.ch_weight(ALUFPMul, fmul_lat - 1)
                    || cur_edge.ch_weight(ALUFPDiv, fmul_lat - 1)
                    || cur_edge.ch_weight(ALUFPCvt, fmul_lat - 1)
                    || cur_edge.ch_weight(ALUFP, fmul_lat - 1);
            }

            if (div_lat >= 0)
                cur_edge.ch_weight(ALUIntDiv, div_lat - 1);

            if (mul_lat >= 0)
                cur_edge.ch_weight(ALUIntMul, mul_lat - 1);

            if (long_lat >= 0){
                double weight = cur_edge.weight();
                weight = weight * (double) long_lat / 100 - 1;

                if (weight < 0)
                    weight = 0;

                cur_edge.ch_weight(ALUIntMul, weight)
                    || cur_edge.ch_weight(ALUIntDiv, weight)
                    || cur_edge.ch_weight(ALUFPAdd, weight)
                    || cur_edge.ch_weight(ALUFPSub, weight)
                    || cur_edge.ch_weight(ALUFPMul, weight)
                    || cur_edge.ch_weight(ALUFPDiv, weight)
                    || cur_edge.ch_weight(ALUFP, weight)
                    || cur_edge.ch_weight(ALUFPCvt, weight);
            }

            // if (cur_edge.typecheck(DCacheL1Hit))
            //     cerr << cur_edge.weight() << '\n';
            // if (cur_edge.typecheck(DCacheMemHit))
            //     cerr << cur_edge.weight() << '\n';

            // if (cur_edge.typecheck(L1Hit_L1CachelineSharing)
            //     || cur_edge.typecheck(L2Hit_L1CachelineSharing)
            //     ||cur_edge.typecheck (L2Miss_L1CachelineSharing)
            //     ||cur_edge.typecheck (L2Hit_L2CachelineSharing)
            //     ||cur_edge.typecheck (L2Miss_L2CachelineSharing)
            //     ||cur_edge.typecheck (L2Miss_BankSharing))
            //     cerr << cur_edge.weight() << '\n';

            // if (cur_edge.typecheck(DTLB_L1Hit))
            //     cerr << cur_edge.weight() << '\n';
            _stat.update(cur_edge);

            u_int64_t result = cur_state.get_cycle() + cur_edge.weight();
            buffer[cur_edge.get_distance()].update_cycle(result);
            update(cur_stat, cur_edge, stat_buffer[cur_edge.get_distance()]);

            // CP_buffer
            cp_update(cur_cps, cur_edge, cp_buffer[cur_edge.get_distance()], cur_state.get_type(), threshold);

            ++i;
        }
        prev_cps = &cur_cps;
        // if (cur_state.get_type() == Issue){
        //   cout << cur_state.get_cycle() << '\n';
        // }
        if (buffer.size() == 1){
            state_counter = cur_state.get_idx() + 1;
            cur_stat.merge_stat();
            cout << "Cycles: " << cur_stat.get_cycle() << endl;
            cout << "=============== Critical Path Stats ===============" << endl;
            cout << cur_stat << endl;

            cout << "=============== Representative Paths =============" << endl;
            print_cps(cout, cur_cps, weight_percent, entry_percent);
        }
        buffer.pop_front();
        stat_buffer.pop_front();
        cp_buffer.pop_front();
        //cur_cps.clear();
        num_buffer.pop_front();
        load();
    }
    cout << "================ Total Edge Stats ================" << endl;
    cout << "Average # of edges " << num_edges / state_counter << endl;
    cout << _stat << endl;

    /*
    // DEBUG: base penalty decomposition
    for (int i = 0; i < 255; i++)
      if(penalty_counter[i] != 0)
        cout << "Penalty " << i << ": " << penalty_counter[i] << endl;

    // DEBUG: L1D latency distribution
    for (int i = 0; i < 1024; i++)
      if(l1d_cycles_hist[i] != 0)
        cout << "L1D Latency/Count: " << i << " / " << l1d_cycles_hist[i] << endl;
    */
}

void converter::issueq_insert(u_int64_t cycle, stat& s){
    vector<pair<u_int64_t, stat> >::iterator it;
    for (it = issueq.begin(); it != issueq.end(); ++it)
        if (it->first < cycle)
            break;

    issueq.insert(it, make_pair(cycle, s));
}

void converter::clear_cp_buffer(){
    size_t size = cp_buffer.size();
    size_t sum_freed = 0;

    cerr << "CP_buffer size: " << cp_buffer.size();
    for (size_t i = 0; i < size; ++i)
    {
        sum_freed += cp_buffer[i].capacity();
        cp_buffer[i].clear();
    }
    cerr << "  Amount freed: " << sum_freed << endl;
    return;
}
