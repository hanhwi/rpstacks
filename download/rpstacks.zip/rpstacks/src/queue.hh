// Copyright 2014 Hanhwi Jang, Jaewon Lee, Jae-Eon Jo, and Jangwoo Kim

// Redistribution and  use in  source and binary  forms, with  or without
// modification, are permitted provided that the following conditions are
// met:

// 1.  Redistributions of  source code  must retain  the above  copyright
// notice, this list of conditions and the following disclaimer.

// 2. Redistributions in  binary form must reproduce  the above copyright
// notice, this  list of conditions  and the following disclaimer  in the
// documentation and/or other materials provided with the distribution.

// 3.  Neither the  name of  the copyright  holder nor  the names  of its
// contributors may be  used to endorse or promote  products derived from
// this software without specific prior written permission.

// THIS SOFTWARE  IS PROVIDED BY  THE COPYRIGHT HOLDERS  AND CONTRIBUTORS
// "AS  IS" AND  ANY EXPRESS  OR IMPLIED  WARRANTIES, INCLUDING,  BUT NOT
// LIMITED TO, THE IMPLIED WARRANTIES  OF MERCHANTABILITY AND FITNESS FOR
// A PARTICULAR PURPOSE  ARE DISCLAIMED. IN NO EVENT  SHALL THE COPYRIGHT
// HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
// SPECIAL,  EXEMPLARY,  OR  CONSEQUENTIAL DAMAGES  (INCLUDING,  BUT  NOT
// LIMITED TO, PROCUREMENT OF SUBSTITUTE  GOODS OR SERVICES; LOSS OF USE,
// DATA, OR PROFITS; OR BUSINESS  INTERRUPTION) HOWEVER CAUSED AND ON ANY
// THEORY OF  LIABILITY, WHETHER IN  CONTRACT, STRICT LIABILITY,  OR TORT
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN  ANY WAY OUT OF THE USE
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

#ifndef _QUEUE_HH
#define _QUEUE_HH
#include <cstddef>
#include <iostream>
#include <cassert>

template <size_t N>
class rot_idx{
  template <size_t U> friend std::ostream &operator <<(std::ostream &, const rot_idx<U> &);
public:
  rot_idx &operator ++() {
    i = conv_idx(i+1);
    return *this;
  }
  rot_idx &operator --() {
    i = conv_idx(i-1);
    return *this;
  }

  bool operator !=(const rot_idx& r_idx) { return i != r_idx.i; }
  size_t operator + (size_t j) { return conv_idx(i + j); }
  operator size_t() { return i; }
  rot_idx()
    : i(0)
  {}
  rot_idx(size_t i)
    : i(i)
  {}
  static size_t conv_idx(size_t i){
    return (i + N) % N;
  }
private:
  size_t i;
};

template <size_t N>
std::ostream &operator << (std::ostream &os, const rot_idx<N> &ri){
  return os << ri.i;
}

template <class T, size_t N>
class static_queue{
  template <class U, size_t V>
  friend std::ostream &operator << (std::ostream &, const static_queue<U, V> &);
public:
  typedef size_t size_type;
  typedef T value_type;
  typedef rot_idx<N+1> idx_type;

  static_queue()
    : cur(0), _end(0), prev_end(0), num(0)
  {}
  T& operator [](size_type i){
    return buffer[cur + i];
  }
  const T& operator [](size_type i) const{
    return buffer[cur + i];
  }
  T& front(){
    return buffer[cur];
  }

  T& back(){
    return buffer[prev_end];
  }

  void pop_front(){
    ++cur;
    --num;
    assert(num>=0);
  }
  void pop_end(){
    --_end;
    --prev_end;
    --num;
    assert(num>=0);
  }
  T& alloc(){
    assert (num < N);
    prev_end = _end;
    ++_end;
    ++num;
    return buffer[prev_end];
  }
  idx_type begin() { return cur; }
  idx_type end() { return _end; }
  bool empty() { return num == 0; }
  bool full() { return num == N; }
  size_t size() { return num; }
private:
  idx_type cur;
  idx_type _end;
  idx_type prev_end;
  T buffer[N+1];
  size_type num;
};

template <class T, size_t N>
std::ostream &operator << (std::ostream &os, const static_queue<T, N> &q){
  for (typename static_queue<T, N>::idx_type i = q.cur; i != q._end; ++i)
    os << q[i] << ' ';
  return os;
}
#endif
