// Copyright 2014 Hanhwi Jang, Jaewon Lee, Jae-Eon Jo, and Jangwoo Kim

// Redistribution and  use in  source and binary  forms, with  or without
// modification, are permitted provided that the following conditions are
// met:

// 1.  Redistributions of  source code  must retain  the above  copyright
// notice, this list of conditions and the following disclaimer.

// 2. Redistributions in  binary form must reproduce  the above copyright
// notice, this  list of conditions  and the following disclaimer  in the
// documentation and/or other materials provided with the distribution.

// 3.  Neither the  name of  the copyright  holder nor  the names  of its
// contributors may be  used to endorse or promote  products derived from
// this software without specific prior written permission.

// THIS SOFTWARE  IS PROVIDED BY  THE COPYRIGHT HOLDERS  AND CONTRIBUTORS
// "AS  IS" AND  ANY EXPRESS  OR IMPLIED  WARRANTIES, INCLUDING,  BUT NOT
// LIMITED TO, THE IMPLIED WARRANTIES  OF MERCHANTABILITY AND FITNESS FOR
// A PARTICULAR PURPOSE  ARE DISCLAIMED. IN NO EVENT  SHALL THE COPYRIGHT
// HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
// SPECIAL,  EXEMPLARY,  OR  CONSEQUENTIAL DAMAGES  (INCLUDING,  BUT  NOT
// LIMITED TO, PROCUREMENT OF SUBSTITUTE  GOODS OR SERVICES; LOSS OF USE,
// DATA, OR PROFITS; OR BUSINESS  INTERRUPTION) HOWEVER CAUSED AND ON ANY
// THEORY OF  LIABILITY, WHETHER IN  CONTRACT, STRICT LIABILITY,  OR TORT
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN  ANY WAY OUT OF THE USE
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

#ifndef _INST_H
#define _INST_H
#include <vector>
#include <map>
#include <iostream>
#include <string>
#include <utility>
#include <cassert>
#include <set>
#include "const.hh"
#include "queue.hh"
#include "array.hh"
#include <sys/types.h>

template <class t>
std::ostream &operator ,(std::ostream &os, t c);

//State type
enum {Fetch, ITLB, ICache, Rename, Dispatch, AddrReady, AddrGen, DTLB,
      Ready, Issue, Complete, ReadyToCommit, Commit, StateNum};

const int state_num_ = 11;

//edge type

#define GEN_ENUM(x) x,
#define GEN_NAME(x) #x,
#define GEN_EDGE_TYPE(f)                                                \
    f(InorderFetch) f(RedispatchBranchMiss) f(FetchWidthLimit) f(FQShortage) \
    f(ICacheBlockFetch) f(BranchMiss)                                   \
    f(ITLBHit) f(ITLBMiss) f(ITLB_IBufferHit) f(ITLB_L1Hit) f(ITLB_L2Hit) f(ITLB_MemHit) \
    f(ICacheL1Hit) f(ICacheL2Hit) f(ICacheMemHit) f(RenameBaseDelay)    \
    f(PhysregShortage) f(LDQShortage) f(STQShortage) f(LSQShortage) f(ROBShortage) \
    f(FrontendDelay) f(IQShortage) f(Redispatch) f(InorderDispatch) f(DispatchWidthLimit) \
    f(Transfer) f(MemAddrWaiting) f(MemDataDep) f(MemAddr)              \
    f(FUMULShortage) f(FUDIVShortage) f(FUFPADDShortage) f(FUFPSUBShortage) \
    f(FUFPMULShortage) f(FUFPDIVShortage) f(FUFPShortage) f(FUFPCVTShortage) f(FUBaseShortage) \
    f(FUAddrShortage)                                                   \
    f(ReadyBaseDelay)                                                   \
    f(FUBaseLat) f(ALUIntMul) f(ALUIntDiv) f(ALUFPAdd) f(ALUFPSub) f(ALUFPMul) f(ALUFPDiv) f(ALUFP) f(ALUFPCvt) \
    f(MfLat) f(DCacheL1Hit) f(DCacheL2Hit) f(DCacheMemHit)              \
    f(Back_DCacheL1Hit) f(Back_DCacheL2Hit) f(Back_DCacheMemHit)        \
    f(L1Hit_H_L1CachelineSharing) f(L2Hit_H_L1CachelineSharing) f(L2Miss_H_L1CachelineSharing) \
    f(L1Hit_L_L1CachelineSharing) f(L2Hit_L_L1CachelineSharing) f(L2Miss_L_L1CachelineSharing) \
    f(Br_L1Hit_H_L1CachelineSharing) f(Br_L2Hit_H_L1CachelineSharing) f(Br_L2Miss_H_L1CachelineSharing) \
    f(Br_L1Hit_L_L1CachelineSharing) f(Br_L2Hit_L_L1CachelineSharing) f(Br_L2Miss_L_L1CachelineSharing) \
    f(L2Hit_L2CachelineSharing) f(L2Miss_L2CachelineSharing)            \
    f(Br_L2Hit_L2CachelineSharing) f(Br_L2Miss_L2CachelineSharing)      \
    f(L2Miss_BankSharing)	f(Br_L2Miss_BankSharing)                    \
    f(CommitBaseDelay)                                                  \
    f(InorderCommit) f(CommitWidthLimit)                                \
    f(DTLBHit) f(DTLBMiss) f(DTLB_L1Hit) f(DTLB_L2Hit) f(DTLB_MemHit)  \
    f(IssueBaseDelay) f(DcacheStall)                                    \
    f(Exception) f(SMC) f(MemLocked) f(CommitInterrupt) f(CommitBarrier) f(CommitStop) \
    f(InorderFrontend) f(FrontendWidthLimit) f(InterruptFetchBlocked) f(BRP) \
    f(BrBase) f(BrALUIntMul) f(BrALUIntDiv) f(BrALUFPAdd) f(BrALUFPSub) f(BrALUFPMul) f(BrALUFPDiv) \
    f(BrALUFP) f(BrALUFPCvt) f(BrICacheL1Hit) f(BrICacheL2Hit) f(BrICacheMemHit) \
    f(BrDCacheL1Hit) f(BrDCacheL2Hit) f(BrDCacheMemHit) f(BrITLBMiss) f(BrDTLBMiss) f(LoadBaseLat)


enum { GEN_EDGE_TYPE(GEN_ENUM) EdgeTypeNum };
extern const char * edge_type_name[];

//Penalty type
#define GEN_PENALTY_TYPE(f)                                             \
    f(FetchPenalty) f(BranchMissPenalty) f(FQLimitPenalty) f(ITLBMissPenalty) f(ICacheMissPenalty) \
    f(RenamePenalty) f(InorderRenamePenalty) f(ResourceShortagePenalty) f(DispatchPenalty) f(InorderDispatchPenalty) f(IQPenalty) \
    f(ReadyPipelinePenalty) f(TransferPenalty) f(MemAddrPenalty) f(FUShortagePenalty) f(MemDataDepPenalty) \
    f(FUPenalty) f(DTLBMissPenalty) f(CachelineSharingPenalty) f(UOPCommitPenalty) f(CommitPenalty) f(CommitBlockedPenalty)

enum { GEN_PENALTY_TYPE(GEN_ENUM) PenaltyTypeNum };
extern const char * penalty_name[];

//Mem Miss
enum {L1Hit, L2Hit, L2Miss, Wait};

//Register
enum {RD, MF, RA, RB, RC, RS, OpearndNum};

class _trace_info{
    friend std::ostream &operator << (std::ostream &os, _trace_info &tr);
public:
    _trace_info()
    {
        cachelines.reserve(3);
    }
    u_int64_t fetch;
    int fq_in_delay;
    int itlb_delay;
    int icache_delay;
    int rename_try_delay;
    int rename_rob_suf_cond_delay;
    int rename_physreg_suf_cond_delay;
    int rename_ldq_suf_cond_delay;
    int rename_stq_suf_cond_delay;
    int rename_lsq_suf_cond_delay;
    int rename_delay;
    int iq_full_delay;
    int dispatch_delay;
    int redispatch_delay;
    int addrgen_ready_delay;
    int addrgen_delay;
    int dtlb_delay;
    int ready_delay;
    int issue_delay;
    int complete_delay;
    int ready_to_commit_delay;
    int commit_delay;
    int icache;
    int dcache;
    std::pair<int, int> dtlb_miss[tlb_walk_level];
    std::pair<int, int> itlb_miss[tlb_walk_level];
    bool som;
    bool eom;
    bool redispatch;
    std::string opcode;
	int alutype;
    int reg_rd;
    int reg_ra;
    int reg_rb;
    int reg_rc;
    int reg_rs;
    int reg_mf;
    bool physreg_full;
    bool lsq_full;
    bool ldq_full;
    bool stq_full;
    bool internal;
    bool mf;
    bool first_branch_mpred;
    bool last_branch_mpred;
    bool taken;
    int store_dcache_stall;
    int exception_stall;
    int smc_stall;
    int memlocked;
    bool barrier, stop, interrupt, invalid;
    int fu_lat;
    std::vector<u_int64_t> cachelines;
    std::set<int> data_deps;
    std::set<int> addr_deps;
    std::vector<int> wakeup;
    std::vector<int> wakeup_id;
    int who_wakeup;
    int free_reg;
    int rob_id;
    u_int64_t physaddr;
    bool diff;
    //PTLsim(x86) cannot free the physical register mapped to
    //previous instruction's destination architecture registerer
    //because of flags (refer PTLsim user's guide 24.5)
    //pending_free_regs contains the register freed at the instruction's renaming cycle.
    std::vector<int> pending_free_regs;

    //Initialize the class with data from standard input
    bool load();
    bool isload();
    bool isstore();
    bool isbr();
    bool isbrp();
    bool issom() { return som; }
    bool iseom() { return eom; }
    bool ismf() { return mf; }
    bool istaken() { return taken; }
    bool br_miss() { return last_branch_mpred; }
    u_int64_t fetch_cycle();
    u_int64_t fq_in_cycle();
    u_int64_t itlb_cycle();
    u_int64_t icache_cycle();
    u_int64_t rename_cycle();
    u_int64_t rename_done_cycle();
    u_int64_t dispatch_cycle();
    u_int64_t addrready_cycle();
    u_int64_t addrgen_cycle();
    u_int64_t dtlb_cycle();
    u_int64_t ready_cycle();
    u_int64_t issue_cycle();
    u_int64_t complete_cycle();
    u_int64_t commit_cycle(){
        return complete_cycle() + ready_to_commit_delay + commit_delay;
    }

    std::ostream &print(std::ostream &os);
};

std::ostream &operator << (std::ostream &os, _trace_info &tr);

class _penalty{
    friend std::ostream &operator << (std::ostream &os, _penalty &p);
public:
    int type;
    int weight;
    _penalty(){}
    _penalty(int type, int weight)
        :type(type), weight(weight)
    {}

    static bool is_frontend(int penalty_type){
        switch (penalty_type){
        case ITLBMiss:
        case ICacheL2Hit:
        case ICacheMemHit:
        case BrITLBMiss:
        case BrICacheL1Hit:
        case BrICacheL2Hit:
        case BrICacheMemHit:
            return true;
            break;
        default:
            return false;
        }
    }

    static bool is_backend(int penalty_type){
        switch (penalty_type){
        case DTLBMiss:
        case ALUIntMul:
        case ALUIntDiv:
        case ALUFPAdd:
        case ALUFPSub:
        case ALUFPMul:
        case ALUFPDiv:
        case ALUFP:
        case ALUFPCvt:
        case DCacheL2Hit:
        case DCacheMemHit:
        case L2Hit_H_L1CachelineSharing:
        case L2Miss_H_L1CachelineSharing:
        case L2Hit_L_L1CachelineSharing:
        case L2Miss_L_L1CachelineSharing:
        case L2Hit_L2CachelineSharing:
        case L2Miss_L2CachelineSharing:
        case L2Miss_BankSharing:
        case Br_L2Hit_H_L1CachelineSharing:
        case Br_L2Miss_H_L1CachelineSharing:
        case Br_L2Hit_L_L1CachelineSharing:
        case Br_L2Miss_L_L1CachelineSharing:
        case Br_L2Hit_L2CachelineSharing:
        case Br_L2Miss_L2CachelineSharing:
        case Br_L2Miss_BankSharing:
        case BrDTLBMiss:
        case BrALUIntMul:
        case BrALUIntDiv:
        case BrALUFPAdd:
        case BrALUFPSub:
        case BrALUFPMul:
        case BrALUFPDiv:
        case BrALUFP:
        case BrALUFPCvt:
        case BrDCacheL2Hit:
        case BrDCacheMemHit:
            return true;
            break;
        default:
            return false;
        }
    }

    bool is_frontend()
    {
        return is_frontend(type);
    }

    bool is_backend()
    {
        return is_backend(type);
    }
};
std::ostream &operator << (std::ostream &os, _penalty &p);

class edge{
    friend std::ostream &operator << (std::ostream &os, edge &e);
private:
    int target_distance;
    static const int max_num_penalty = 10;
    array<_penalty, max_num_penalty> penalty_list;
public:
    typedef array<_penalty, max_num_penalty> penalty_list_t;
    edge(){};
    bool typecheck(int type);
    void add_penalty(int type, int weight);
    bool ch_weight(int type, int weight, int ch_type = -1);
    bool ch_weight_inc(int type, int diff, int default_weight, int ch_type = -1);
    void set_distance(int distance) { this->target_distance = distance; }
    int get_distance(){ return target_distance; }
    penalty_list_t &get_penalties() { return penalty_list; }
    int get_penalty_weight(int type);
    int weight();
    bool is_frontend(){
        for (int i = 0; i != penalty_list.end(); i++)
            if (penalty_list[i].is_frontend())
                return true;
        return false;
    }
    bool is_backend(){
        for (int i = 0; i != penalty_list.end(); i++)
            if (penalty_list[i].is_backend())
                return true;
        return false;
    }
    std::ostream & print(std::ostream &os);
};
std::ostream &operator << (std::ostream &os, edge &e);

class state{
    friend std::ostream &operator << (std::ostream &os, state &s);
private:
    u_int64_t cycle;
    //Tracking distance
    static u_int64_t count;
    static const int num_edges = rob_size * 2;
    int type;
    u_int64_t idx;
    array<edge, num_edges> edges;
public:
    state()
        : cycle(0)
    {
    }
    void add_edge(edge &l);
    void del_edge(int i);
    array<edge, num_edges> &get_edges() { return edges; }
    std::ostream & print(std::ostream &os);
    u_int64_t set_cycle(u_int64_t cycle) {
        return this->cycle = cycle;
    }
    u_int64_t get_cycle(){ return cycle; }
    void update_cycle(u_int64_t new_result) { cycle = new_result > cycle ? new_result : cycle; }
    u_int64_t get_idx(){ return idx; }
    void set_type(int type){ this->type = type; }
    int get_type() { return this->type; }
    void init() {
        idx = ++count;
        reset();
    }
    void init(int type) {
        this->type = type;
        init();
    }
    void reset(){
        edges.reset();
    }
};

std::ostream &operator << (std::ostream &os, state &s);

class macroOp;

class uop{
private:
    //state to idx mapping table
    static const int map_type1[StateNum];
    static const int map_type2[StateNum];
    static char ss_to_p[StateNum][StateNum];
    static uop *uop_buffer;
    static int uop_buffer_size;
    _trace_info trace_info;
    static int count;
    static bool first;
    state states[StateNum];
    int states_num;
    u_int64_t id;
    macroOp* mop;
    const int *state_map;
public:
    uop()
        :mop(NULL)
    {}

    u_int64_t add_edge(u_int64_t waiting_uop_id, int waiting_state, int to_state, int aux = 0);
    u_int64_t get_id(){
        return id;
    }
    bool init();
    void clear(){
        mop = NULL;
    }
    int get_num_of_states();
    int get_state_idx(int state);
    u_int64_t get_cycle(int state);
    int get_regid(int reg);
    std::set<int> &get_addr_deps() { return trace_info.addr_deps; }
    std::set<int> &get_data_deps() { return trace_info.data_deps; }
    u_int64_t get_physaddr() { return trace_info.physaddr; }
    int get_free_reg() { return trace_info.free_reg; }
    std::vector<int> &get_pending_free_regs() { return trace_info.pending_free_regs; }
    std::vector<int> &get_wakeup() { return trace_info.wakeup; }
    int get_who_wakeup() { return trace_info.who_wakeup; }
    int get_robid() { return trace_info.rob_id; }
    bool issom() { return trace_info.issom(); }
    bool iseom() { return trace_info.iseom(); }
    bool isload() { return trace_info.isload(); }
    bool isstore() { return trace_info.isstore(); }
    bool isbranch() { return trace_info.isbr(); }
    bool ismf() { return trace_info.ismf(); }
    bool br_miss() { return trace_info.br_miss(); }
    int get_dmiss() { return trace_info.dcache; }
    void set_dmiss(int dmiss) { trace_info.dcache = dmiss; }
    u_int64_t fetch_cycle() { return trace_info.fetch_cycle(); }
    u_int64_t fq_in_cycle() { return trace_info.fq_in_cycle(); }
    u_int64_t itlb_cycle() { return trace_info.itlb_cycle(); }
    u_int64_t icache_cycle() { return trace_info.icache_cycle(); }
    u_int64_t rename_cycle() { return trace_info.rename_cycle(); }
    u_int64_t rename_done_cycle() { return trace_info.rename_done_cycle();}
    u_int64_t dispatch_cycle(){ return trace_info.dispatch_cycle(); }
    u_int64_t addrready_cycle(){ return trace_info.addrready_cycle(); }
    u_int64_t addrgen_cycle(){ return trace_info.addrgen_cycle(); }
    u_int64_t dtlb_cycle(){ return trace_info.dtlb_cycle(); }
    u_int64_t ready_cycle(){ return trace_info.ready_cycle(); }
    u_int64_t issue_cycle(){ return trace_info.issue_cycle(); }
    u_int64_t complete_cycle(){ return trace_info.complete_cycle(); }
    u_int64_t commit_cycle(){ return trace_info.commit_cycle(); }
    // 140518 spiegel0
    int instruction_type()
    {
      int alutype = trace_info.alutype;
      // LD
      if (trace_info.isload())
        return 0;
      // ST
      else if (trace_info.isstore())
        return 1;
      // BASE, IMUL, IDIV (2 ~ 4)
      else if (alutype == 0 || alutype == 1 || alutype == 2)
        return alutype + 2;
      // FPADD (5)
      else if (alutype == 3 || alutype == 4 || alutype == 7)
        return 5;
      // FPMULDIV
      else
        return 6;
    }

    void clear_dmiss(){ trace_info.dcache = Wait; }
    u_int64_t set_cycle(int state_idx, u_int64_t cycle){
        return access_state(state_idx).set_cycle(cycle);
    }

    bool cacheline_match(const std::vector<u_int64_t> &cachelines2, int &aux){
        const std::vector<u_int64_t> &cachelines = trace_info.cachelines;
        aux = -1;
        std::vector<u_int64_t>::const_iterator it = cachelines.begin();
        std::vector<u_int64_t>::const_iterator it2 = cachelines2.begin();
        bool found = false;
        while(it != cachelines.end() && it2 != cachelines2.end()){
            if (*it == 0 || *it2 == 0 || *it != *it2)
                return found;
            else if (*it == *it2)
                found = true;
            aux++;
            ++it, ++it2;
        }
        return found;
    }

    const std::vector<u_int64_t> & get_cachelines(){
        return trace_info.cachelines;
    }

    static void set_buffer(uop *buffer, int size) { uop_buffer = buffer; uop_buffer_size = size;}
    uop &access_buffer(int idx){
        return uop_buffer[idx % uop_buffer_size];
    }
    state &access_state(int state_idx){
        return states[state_map[state_idx]];
    }
    static void init_map();
    std::ostream &print(std::ostream &os);
    std::ostream &print_commit(std::ostream &os);
};

std::ostream &operator << (std::ostream &os, uop &inst);

class macroOp{
    friend std::ostream &operator << (std::ostream &os, macroOp &mop);
private:
    static static_queue<macroOp, uop_buffer_size> buffer;
    static std::map<int, uop*> *renaming_table;
    std::vector<uop *> uop_buffer;
    u_int64_t eom_id;
    u_int64_t som_id;
    bool valid;
public:
    macroOp()
        : eom_id(0), som_id(0), valid(false)
    {
    }
    static void set_renaming_table(std::map<int, uop*> *renaming_table);
    static macroOp* add_uop(uop *inst);
    std::ostream & print(std::ostream &os);
    void init(){
        uop_buffer.clear();
        valid = false;
        som_id = 0;
        eom_id = 0;
    }

    static macroOp &alloc() {
        macroOp &temp = buffer.alloc();
        temp.init();
        return temp;
    }

    int size() { return uop_buffer.size(); }
    bool is_this_uop_in(u_int64_t uop_id);
    static static_queue<macroOp, uop_buffer_size> & get_list() { return buffer; }
    bool isvalid() { return valid; }
    void clear();
};

std::ostream &operator << (std::ostream &os, macroOp &mop);
#endif
