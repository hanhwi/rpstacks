// Copyright 2014 Hanhwi Jang, Jaewon Lee, Jae-Eon Jo, and Jangwoo Kim

// Redistribution and  use in  source and binary  forms, with  or without
// modification, are permitted provided that the following conditions are
// met:

// 1.  Redistributions of  source code  must retain  the above  copyright
// notice, this list of conditions and the following disclaimer.

// 2. Redistributions in  binary form must reproduce  the above copyright
// notice, this  list of conditions  and the following disclaimer  in the
// documentation and/or other materials provided with the distribution.

// 3.  Neither the  name of  the copyright  holder nor  the names  of its
// contributors may be  used to endorse or promote  products derived from
// this software without specific prior written permission.

// THIS SOFTWARE  IS PROVIDED BY  THE COPYRIGHT HOLDERS  AND CONTRIBUTORS
// "AS  IS" AND  ANY EXPRESS  OR IMPLIED  WARRANTIES, INCLUDING,  BUT NOT
// LIMITED TO, THE IMPLIED WARRANTIES  OF MERCHANTABILITY AND FITNESS FOR
// A PARTICULAR PURPOSE  ARE DISCLAIMED. IN NO EVENT  SHALL THE COPYRIGHT
// HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
// SPECIAL,  EXEMPLARY,  OR  CONSEQUENTIAL DAMAGES  (INCLUDING,  BUT  NOT
// LIMITED TO, PROCUREMENT OF SUBSTITUTE  GOODS OR SERVICES; LOSS OF USE,
// DATA, OR PROFITS; OR BUSINESS  INTERRUPTION) HOWEVER CAUSED AND ON ANY
// THEORY OF  LIABILITY, WHETHER IN  CONTRACT, STRICT LIABILITY,  OR TORT
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN  ANY WAY OUT OF THE USE
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

#include "stat.hh"
#include <algorithm>
#include <iterator>
#include <utility>
#include <cmath>

using namespace std;

stat::stat(){
    init();
}

void stat::init(){
    std::fill(penalty_counter, penalty_counter + EdgeTypeNum, 0);
    std::fill(penalty_cycle, penalty_cycle + EdgeTypeNum, 0);
    total_cycle = 0;
    diff = 0;
    path.clear();
    path.reserve(1000);
}

void stat::set_diff(u_int64_t diff, int force){
    if (force || diff < this->diff)
        this->diff = diff;
}

u_int64_t stat::get_cycle(){
    return total_cycle;
}

u_int64_t stat::get_penalty(int i){
    return penalty_cycle[i];
}

void stat::update(edge &e){
    edge::penalty_list_t &penalty_list = e.get_penalties();
    u_int64_t total_weight = 0;
    garbage_collect();
    for (int i = 0; i < penalty_list.end(); ++i){
        assert(penalty_list[i].weight >= 0);
        total_weight += penalty_list[i].weight;
        ++penalty_counter[penalty_list[i].type];
#ifdef BR_COUNT_T
        if (penalty_list[i].weight > 0)
            path.push_back(make_pair(penalty_list[i].type, penalty_list[i].weight));
#else
        penalty_cycle[penalty_list[i].type] += penalty_list[i].weight;
#endif
    }
    total_cycle += total_weight;
}

void stat::merge_stat(){
    for (vector<pair<int, int> >::iterator it = path.begin();
         it != path.end(); ++it)
        penalty_cycle[it->first] += it->second;
    path.clear();
}

void stat::garbage_collect(){
    vector<pair<int, int> > temp;
    temp.reserve(300);
    if (path.size() > 2000){
        for (int i = 0; i < 1000; ++i)
            penalty_cycle[path[i].first] += path[i].second;

        for (int i = 1000; i < path.size(); ++i)
            temp.push_back(path[i]);
        path.clear();
        path = temp;
    }
}

void stat::update_branch(){
    int weight = diff;
    //Adjusting branch weight by stealing previous penalty event's cycles
    vector<pair<int, int> >::reverse_iterator it = path.rbegin();

    if (path.empty())
        return;

    //Function only works when the path passes BranchMiss
    if (it->first != BranchMiss)
        return;

    for (; it != path.rend(); ++it){
        if (!weight)
            break;

        int temp_type;
        switch (it->first){
        case ALUIntMul:
            temp_type = BrALUIntMul;
            break;
        case ALUIntDiv:
            temp_type = BrALUIntDiv;
            break;
        case ALUFP:
            temp_type = BrALUFP;
            break;
        case ALUFPCvt:
            temp_type = BrALUFPCvt;
            break;
        case ICacheL1Hit:
            temp_type = BrICacheL1Hit;
            break;
        case ICacheL2Hit:
            temp_type = BrICacheL2Hit;
            break;
        case ICacheMemHit:
            temp_type = BrICacheMemHit;
            break;
        case ITLBMiss:
            temp_type = BrITLBMiss;
            break;
        case DCacheL1Hit:
            temp_type = BrDCacheL1Hit;
            break;
        case DCacheL2Hit:
            temp_type = BrDCacheL2Hit;
            break;
        case DCacheMemHit:
            temp_type = BrDCacheMemHit;
            break;
        case DTLBMiss:
            temp_type = BrDTLBMiss;
            break;
        case L1Hit_H_L1CachelineSharing:
            temp_type = Br_L1Hit_H_L1CachelineSharing;
            break;
        case L2Hit_H_L1CachelineSharing:
            temp_type = Br_L2Hit_H_L1CachelineSharing;
            break;
        case L2Miss_H_L1CachelineSharing:
            temp_type = Br_L2Miss_H_L1CachelineSharing;
            break;
        case L1Hit_L_L1CachelineSharing:
            temp_type = Br_L1Hit_L_L1CachelineSharing;
            break;
        case L2Hit_L_L1CachelineSharing:
            temp_type = Br_L2Hit_L_L1CachelineSharing;
            break;
        case L2Miss_L_L1CachelineSharing:
            temp_type = Br_L2Miss_L_L1CachelineSharing;
            break;
        case L2Hit_L2CachelineSharing:
            temp_type = Br_L2Hit_L2CachelineSharing;
            break;
        case L2Miss_L2CachelineSharing:
            temp_type = Br_L2Miss_L2CachelineSharing;
            break;
        case L2Miss_BankSharing:
            temp_type = Br_L2Miss_BankSharing;
            break;
        default:
            temp_type = BrBase;
            break;
        }

        ++penalty_counter[temp_type];
        if (it->second > weight){
            //update counter
            penalty_cycle[temp_type] += weight;
            it->second = it->second - weight;
            weight = 0;
        }
        else{
            weight -= it->second;
            it->first = temp_type;
        }
    }
    assert(!weight);
    merge_stat();
    return;
}

std::ostream & stat::print(std::ostream &os) const{
    os << ';';
    std::copy(edge_type_name, edge_type_name + EdgeTypeNum, std::ostream_iterator<const char *> (os, ";"));
    os << std::endl;
    os << "counter;";
    std::copy(penalty_counter, penalty_counter + EdgeTypeNum, std::ostream_iterator<u_int64_t> (os, ";"));
    os << std::endl;
    os << "cycle;";
    std::copy(penalty_cycle, penalty_cycle + EdgeTypeNum, std::ostream_iterator<u_int64_t> (os, ";"));
    os << "total_cycle;" << total_cycle;
    return os;
}

std::ostream & stat::summary(std::ostream &os) const{
    // enum t_stack {tBase, tL1i, tL2i, tItlb, tL1d, tL2d, tDtlb, tLat, tBr, t_NUM};
	enum t_stack {
        base,
        tL1I, tL1D, tL2I, tL2D,
        tMemI, tMemD, tMemItlb, tMemDtlb,
        tALUIntMul, tALUIntDiv,
        tALUFP, tALUFPCvt,
        tBr,
        t_NUM
    };



    u_int64_t t_cycle[t_NUM];

    for (int i = 0; i < t_NUM; ++i)
        t_cycle[i] = 0;

    for (int i = 0; i < EdgeTypeNum; ++i){
        //Contert penalty type to stack entry type
        switch (i){
        case ITLBMiss:
            t_cycle[tMemItlb] += penalty_cycle[i];
            break;
        case ICacheL1Hit:
            t_cycle[tL1I] += penalty_cycle[i];
            break;
        case ICacheL2Hit:
            t_cycle[tL2I] += penalty_cycle[i];
            break;
        case ICacheMemHit:
            t_cycle[tMemI] += penalty_cycle[i];
            break;
        case DTLBMiss:
            t_cycle[tMemDtlb] += penalty_cycle[i];
            break;
        case DCacheL1Hit:
            t_cycle[tL1D] += penalty_cycle[i];
            break;
        case DCacheL2Hit:
        case L2Hit_H_L1CachelineSharing:
        case L2Hit_L_L1CachelineSharing:
        case L2Hit_L2CachelineSharing:
            t_cycle[tL2D] += penalty_cycle[i];
            break;
        case DCacheMemHit:
        case L2Miss_H_L1CachelineSharing:
        case L2Miss_L_L1CachelineSharing:
        case L2Miss_L2CachelineSharing:
        case L2Miss_BankSharing:
            t_cycle[tMemD] += penalty_cycle[i];
            break;
        case ALUIntMul:
            t_cycle[tALUIntMul] += penalty_cycle[i];
            break;
        case ALUIntDiv:
            t_cycle[tALUIntDiv] += penalty_cycle[i];
            break;
        case ALUFP:
            t_cycle[tALUFP] += penalty_cycle[i];
            break;
        case ALUFPCvt:
            t_cycle[tALUFPCvt] += penalty_cycle[i];
            break;
        case BranchMiss:
        case RedispatchBranchMiss:
        case Br_L1Hit_H_L1CachelineSharing:
        case Br_L2Hit_H_L1CachelineSharing:
        case Br_L2Miss_H_L1CachelineSharing:
        case Br_L1Hit_L_L1CachelineSharing:
        case Br_L2Hit_L_L1CachelineSharing:
        case Br_L2Miss_L_L1CachelineSharing:
        case Br_L2Hit_L2CachelineSharing:
        case Br_L2Miss_L2CachelineSharing:
        case Br_L2Miss_BankSharing:
        case BrBase:
            t_cycle[tBr] += penalty_cycle[i];
            break;
        default:
            break;
        }
    }
    std::copy(t_cycle, t_cycle + t_NUM, std::ostream_iterator<u_int64_t> (os, " "));
    os << endl;
    return os;
}

std::ostream & operator <<(std::ostream &os, const stat& s){
    return s.print(os);
}

void update(stat &src, edge &e, stat &dest){
    if (src.get_cycle() + e.weight() > dest.get_cycle()){
        u_int64_t diff = src.get_cycle() + e.weight() - dest.get_cycle();
        dest = src;
        dest.update(e);
        dest.set_diff(diff, 1);
    }
    else {
        u_int64_t diff = dest.get_cycle() - (src.get_cycle() + e.weight());
        dest.set_diff(diff);
    }
}
