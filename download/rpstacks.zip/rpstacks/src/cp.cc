// Copyright 2014 Hanhwi Jang, Jaewon Lee, Jae-Eon Jo, and Jangwoo Kim

// Redistribution and  use in  source and binary  forms, with  or without
// modification, are permitted provided that the following conditions are
// met:

// 1.  Redistributions of  source code  must retain  the above  copyright
// notice, this list of conditions and the following disclaimer.

// 2. Redistributions in  binary form must reproduce  the above copyright
// notice, this  list of conditions  and the following disclaimer  in the
// documentation and/or other materials provided with the distribution.

// 3.  Neither the  name of  the copyright  holder nor  the names  of its
// contributors may be  used to endorse or promote  products derived from
// this software without specific prior written permission.

// THIS SOFTWARE  IS PROVIDED BY  THE COPYRIGHT HOLDERS  AND CONTRIBUTORS
// "AS  IS" AND  ANY EXPRESS  OR IMPLIED  WARRANTIES, INCLUDING,  BUT NOT
// LIMITED TO, THE IMPLIED WARRANTIES  OF MERCHANTABILITY AND FITNESS FOR
// A PARTICULAR PURPOSE  ARE DISCLAIMED. IN NO EVENT  SHALL THE COPYRIGHT
// HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
// SPECIAL,  EXEMPLARY,  OR  CONSEQUENTIAL DAMAGES  (INCLUDING,  BUT  NOT
// LIMITED TO, PROCUREMENT OF SUBSTITUTE  GOODS OR SERVICES; LOSS OF USE,
// DATA, OR PROFITS; OR BUSINESS  INTERRUPTION) HOWEVER CAUSED AND ON ANY
// THEORY OF  LIABILITY, WHETHER IN  CONTRACT, STRICT LIABILITY,  OR TORT
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN  ANY WAY OUT OF THE USE
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

#include "cp.hh"
#include <iterator>
#include <algorithm>
#include <cmath>

using namespace std;

//******************************************************************************
// cp
//******************************************************************************

int global_cntr = 0;
unsigned long long penalty_counter[255];
int l1d_cycles_hist[1024];

cp::cp(){
    init();
}

void cp::init()
{
    _weight = 0;
    accum_weight = 0;
    for (int i = 0; i < stack_entry_num; ++i)
    {
        penalty_cycle[i] = 0;
        penalty_cycle_accum[i] = 0;
    }
    l1d_counter = 0;
    l1i_counter = 0;
    l2d_counter = 0;
    l2i_counter = 0;
    memi_counter = 0;
    memd_counter = 0;
    bank_sharing = 0;
    l1_sharing = 0;
    l2_sharing = 0;
    alu_counter = 0;
    //LAT is not counted here I should modify this.
    lat_counter = 0;
    l1_sharing_weight = 0;
    valid = true;

    is_sharing = false;

    // Improving cos comparison method
    hash = 0;
    ismax = false;

    // Counting base events
    // fetchwlimit = 0;
    // dispatchwlimit = 0;
    // frontendwlimit = 0;
    // commitwlimit = 0;
    // fetch_dispatch_counter = 0;
    // mem_shortage_counter = 0;
    // reg_shortage_counter = 0;
    // rob_shortage_counter = 0;
    // fu_shortage_counter = 0;
    // tfer_counter = 0;
    // datadep_counter = 0;
    // memaddr_counter = 0 ;
    // fubase_counter = 0 ;
    // commitbase_counter = 0 ;
    // retire_counter = 0;
}

void cp::local_init(){
    for (int i = 0; i < stack_entry_num; ++i){
        penalty_cycle[i] = 0;
    }
    _weight = 0;
}

void cp::invalidate(){
    init();
    valid = false;
    return;
}

bool cp::isvalid() const {
    return valid;
}

u_int64_t cp::weight() const {
    return accum_weight;
}

u_int64_t cp::get_base() const {
    return penalty_cycle_accum[base];
}

u_int64_t cp::get_hash() const {
    return hash;
}

void cp::update_hash()
{
  u_int64_t newhash = 0;
  for (int i = 0; i < stack_entry_num; i++)
  {
    // If a penalty entry is nonzero, mark it
    if(penalty_cycle_accum[i] != 0)
      newhash += 1;

    // Change the order
    newhash *= 2;
  }

  hash = newhash;
}

void cp::update(edge &e, int src_stage){

    // Log the origin!
    last_visit_stage = src_stage;
    last_visit_distance = e.get_distance();

    edge::penalty_list_t &penalty_list = e.get_penalties();
    for (int i = 0; i < penalty_list.end(); ++i)
    {
        int weight = penalty_list[i].weight;
        int penalty = penalty_list[i].type;
        int l2i_penalty = 0, l2d_penalty = 0, memi_penalty = 0, memd_penalty = 0;
        switch (penalty)
        {
        case ITLB_L1Hit:
        case ICacheL1Hit:
            //++l1i_counter;
            penalty_cycle[l1i] += weight;
            penalty_cycle_accum[l1i] += weight;
            break;
        case ITLB_L2Hit:
        case ICacheL2Hit:
            //++l2i_counter;
            penalty_cycle[l1i] += l1i_lat_default;
            penalty_cycle_accum[l1i] += l1i_lat_default;
            l2i_penalty = weight - l1i_lat_default;
            if(l2i_penalty < 0)
            {
                cerr << "Adjusting L2 I$ hit penalty: " << l2i_penalty << endl;
                l2i_penalty = 0;
            }
            penalty_cycle[l2i] += l2i_penalty;
            penalty_cycle_accum[l2i] += l2i_penalty;
            break;
        case ITLB_MemHit:
        case ICacheMemHit:
            //++memi_counter;
            penalty_cycle[l1i] += l1i_lat_default;
            penalty_cycle_accum[l1i] += l1i_lat_default;
            penalty_cycle[l2i] += l2i_lat_default;
            penalty_cycle_accum[l2i] += l2i_lat_default;
            memi_penalty = weight - l1i_lat_default - l2i_lat_default;
            if(memi_penalty < 0)
            {
                memi_penalty = 0;
                cerr << "Adjusting MEM I hit penalty" << endl;
            }
            penalty_cycle[mem_i] += memi_penalty;
            penalty_cycle_accum[mem_i] += memi_penalty;
            break;
        case DTLB_L1Hit:
        case L1Hit_L_L1CachelineSharing:
        case L2Hit_L_L1CachelineSharing:
        case L2Miss_L_L1CachelineSharing:
        case DCacheL1Hit:
        // 140507 Added
        case Back_DCacheL1Hit:
            //++l1d_counter;
            penalty_cycle[l1d] += weight;
            penalty_cycle_accum[l1d] += weight;
            l1d_cycles_hist[weight] += 1;
            break;
        case DTLB_L2Hit:
        case DCacheL2Hit:
            //++l2d_counter;
            penalty_cycle[l1d] += l1d_lat_default;
            penalty_cycle_accum[l1d] += l1d_lat_default;
            l1d_cycles_hist[l1d_lat_default] += 1;
            l2d_penalty = weight - l1d_lat_default;
            if(l2d_penalty < 0)
            {
                cerr << "Adjusting L2 D$ hit penalty: " << l2d_penalty << endl;
                penalty_cycle[l1d] += l2d_penalty;
                penalty_cycle_accum[l1d] += l2d_penalty;
                l2d_penalty = 0;
                l1d_cycles_hist[l1d_lat_default] -= 1;
                l1d_cycles_hist[weight] += 1;
            }
            penalty_cycle[l2d] += l2d_penalty;
            penalty_cycle_accum[l2d] += l2d_penalty;

            break;
        case DTLB_MemHit:
        case L1Hit_H_L1CachelineSharing:
        case L2Hit_H_L1CachelineSharing:
        case L2Miss_H_L1CachelineSharing:
            ++l1_sharing;
            // 140507 - 'H' edges belong to base?
            penalty_cycle[base] += weight;
            penalty_cycle_accum[base] += weight;
            //l1_sharing_weight += weight;
            //is_sharing = true;
            break;
        case L2Hit_L2CachelineSharing:
        case L2Miss_L2CachelineSharing:
        case Back_DCacheL2Hit:
            // L2CachelineSharing takes l2 cache latency
            // If L1 data cache is perfect, L2CacheSharing will disappear.
            ++l2_sharing;
            penalty_cycle[l2d] += weight;
            penalty_cycle_accum[l2d] += weight;
            is_sharing = true;
            break;
        case L2Miss_BankSharing:
        case Back_DCacheMemHit:
            ++bank_sharing;
            penalty_cycle[mem_d] += weight;
            penalty_cycle_accum[mem_d] += weight;
            is_sharing = true;
            break;
        case DCacheMemHit:
        {
            //	  ++memd_counter;
            penalty_cycle[l1d] += l1d_lat_default;
            penalty_cycle_accum[l1d] += l1d_lat_default;
            l1d_cycles_hist[l1d_lat_default] += 1;
            penalty_cycle[l2d] += l2d_lat_default;
            penalty_cycle_accum[l2d] += l2d_lat_default;
            memd_penalty = weight - l1d_lat_default - l2d_lat_default;
            if(memd_penalty < 0)
            {
                penalty_cycle[l2d] += memd_penalty;
                penalty_cycle_accum[l2d] += memd_penalty;
                // cerr << "Original MEM D Weight: " << weight << endl;
                cerr << "Adjusting MEM D hit penalty: " << memd_penalty << endl;
                memd_penalty = 0;
            }
            penalty_cycle[mem_d] += memd_penalty;
            penalty_cycle_accum[mem_d] += memd_penalty;
            break;
        }
        case ALUIntMul:
            penalty_cycle[alu_int_mul] += weight;
            penalty_cycle_accum[alu_int_mul] += weight;
            break;
        case ALUIntDiv:
            penalty_cycle[alu_int_div] += weight;
            penalty_cycle_accum[alu_int_div] += weight;
            break;
        case ALUFPAdd:
        case ALUFPSub:
            penalty_cycle[alu_fp_addsub] += weight;
            penalty_cycle_accum[alu_fp_addsub] += weight;
            break;
        case ALUFPMul:
        case ALUFPDiv:
        case ALUFP:
        case ALUFPCvt:
            penalty_cycle[alu_fp_muldiv] += weight;
            penalty_cycle_accum[alu_fp_muldiv] += weight;
            break;
        // 140516 Fixed
        // This almost never happens!
        case BranchMiss:
        case RedispatchBranchMiss:
            //++br_counter;
            penalty_cycle[base] += weight;
            penalty_cycle_accum[base] += weight;
            break;
        case FetchWidthLimit:
            //++fetchwlimit;
            penalty_cycle[base] += weight;
            penalty_cycle_accum[base] += weight;
            break;
        case DispatchWidthLimit:
            //++dispatchwlimit;
            penalty_cycle[base] += weight;
            penalty_cycle_accum[base] += weight;
            break;
        case FrontendWidthLimit:
            //++frontendwlimit;
            penalty_cycle[base] += weight;
            penalty_cycle_accum[base] += weight;
            break;
        case CommitWidthLimit:
            //++commitwlimit;
            penalty_cycle[base] += weight;
            penalty_cycle_accum[base] += weight;
            break;
            // Frontend stall
        case IQShortage:
        case FQShortage:
        case ICacheBlockFetch:
        case FrontendDelay:
        case RenameBaseDelay:
        case InterruptFetchBlocked:
            //++fetch_dispatch_counter;
            penalty_cycle[base] += weight;
            penalty_cycle_accum[base] += weight;
            //penalty_cycle[fetch_dispatch] += weight;
            //penalty_cycle_accum[fetch_dispatch] += weight;
            break;
            // Execution stage stall
            // Mem OP exec stall
        case LDQShortage:
        case STQShortage:
        case LSQShortage:
            penalty_cycle[base] += weight;
            penalty_cycle_accum[base] += weight;
            //++mem_shortage_counter;
            break;
            // Other OP exec stall
        case PhysregShortage:
            penalty_cycle[base] += weight;
            penalty_cycle_accum[base] += weight;
            //++reg_shortage_counter;
            break;
        case ROBShortage:
            penalty_cycle[base] += weight;
            penalty_cycle_accum[base] += weight;
            //++rob_shortage_counter;
            break;
        /*
        case FUShortage:
            penalty_cycle[base] += weight;
            penalty_cycle_accum[base] += weight;
            //++fu_shortage_counter;
            break;
        */
        // Data dependency stall
        case Transfer:
            //++tfer_counter;
            penalty_cycle[base] += weight;
            penalty_cycle_accum[base] += weight;
            break;
        case MemDataDep:
        case MfLat:
            // ++datadep_counter;
            penalty_cycle[base] += weight;
            penalty_cycle_accum[base] += weight;
            break;
            // Mem ADDR calc stall
        case MemAddr:
            // ++memaddr_counter;
            penalty_cycle[base] += weight;
            penalty_cycle_accum[base] += weight;
            break;
            // Commit stalls
        case DcacheStall:
        case Exception:
        case SMC:
        case MemLocked:
        case CommitInterrupt:
        case CommitBarrier:
        case CommitStop:
            // ++retire_counter;
            penalty_cycle[base] += weight;
            penalty_cycle_accum[base] += weight;
            break;
            // Commit base
        case CommitBaseDelay:
            // ++commitbase_counter;
            penalty_cycle[base] += weight;
            penalty_cycle_accum[base] += weight;
            break;
            // FU base
        // 140516 Added
        case FUBaseLat:
            // ++fubase_counter;
            ++alu_counter;
            penalty_cycle[basealu] += weight;
            penalty_cycle_accum[basealu] += weight;
            break;
        default:
            penalty_counter[penalty] += weight;
            penalty_cycle[base] += weight;
            penalty_cycle_accum[base] += weight;
            break;
        }
        _weight += penalty_list[i].weight;
        accum_weight += penalty_list[i].weight;

        update_hash();
    }
}

ostream & cp::print(ostream &os) const{
    copy(penalty_cycle_accum, penalty_cycle_accum + stack_entry_num,  ostream_iterator<int> (os, " "));
    os << l1i_counter << ' '
       << l2i_counter << ' '
       << l1d_counter << ' '
       << l2d_counter << ' '
       << l1_sharing << ' '
       << l2_sharing << ' '
       << bank_sharing << ' '
       << alu_counter << ' '
       << lat_counter << ' '
        // << fetchwlimit << ' '
        // << dispatchwlimit << ' '
        // << frontendwlimit << ' '
        // << commitwlimit << ' '
        // << fetch_dispatch_coㅠunter << ' '
        // << mem_shortage_counter << ' '
        // << reg_shortage_counter << ' '
        // << rob_shortage_counter << ' '
        // << fu_shortage_counter << ' '
        // << tfer_counter << ' '
        // << datadep_counter << ' '
        // << memaddr_counter << ' '
        // << fubase_counter << ' '
        // << commitbase_counter << ' '
        // << retire_counter
       << endl;
    return os;
}

/*
  ostream & cp::print(ostream &os) const{
  copy(penalty_cycle_accum, penalty_cycle_accum + stack_entry_num,  ostream_iterator<int> (os, " "));
  os << l1i_counter << ' ' << l2i_counter << ' ' << l1d_counter << ' ' << l2d_counter <<
  ' ' << l1_sharing << ' ' << l2_sharing << ' ' << bank_sharing << ' ' << br_counter << ' ' << lat_counter << endl;
  return os;
  }
*/

// Original similarity comparisoin function
int64_t cpcmp(const cp &x, const cp &y)
{
    int64_t accum_min = y.penalty_cycle_accum[base] - x.penalty_cycle_accum[base];
    int64_t accum_max = accum_min;

    for (int i = 1; i < stack_entry_num; ++i){
        int64_t diff = y.penalty_cycle_accum[i] - x.penalty_cycle_accum[i];
        //const int l1i_access_diff = y.l1i_counter + y.l2i_counter - x.l1i_counter - x.l2i_counter;
        if (diff > 0){
            accum_max += diff;
            // if (i == l1i)
            // 	accum_min += (l1i_access_diff) * l1i_lat_default;
        }
        else{
            accum_min += diff;
            // if (i == l1i)
            // 	accum_max += (l1i_access_diff) * l1i_lat_default;
        }
    }
    if (accum_min >= 0)
        return 1;
    else if (accum_max <= 0)
        return -1;
    else
        return 0;
}

// Cosine similarity comparison function
int64_t cpcmp_cos(const cp &x, const cp &y, double COS_TH_LOCAL, bool UNIQ_LOCAL)
{
    double x_norm[stack_entry_num], y_norm[stack_entry_num];
    double x_preference = 0, y_preference = 0;
    int x_count, y_count, empty_count;

    x_count = 0;
    y_count = 0;
    empty_count = 0;

    // Convert two vectors into a special normalized form
    for (int i = 0; i < stack_entry_num; ++i)
    {
        if(x.penalty_cycle_accum[i] == 0 && y.penalty_cycle_accum[i] == 0)
        {
            x_norm[i] = 0;
            y_norm[i] = 0;
            empty_count++;
        }
        else if(x.penalty_cycle_accum[i] > y.penalty_cycle_accum[i])
        {
            x_norm[i] = 1.0;
            y_norm[i] = (double) y.penalty_cycle_accum[i] / (double) x.penalty_cycle_accum[i];

            // Save CPs with unique paths
            if(y.penalty_cycle_accum[i] == 0 && UNIQ_LOCAL == true)
                return 0;

            x_count++;
            x_preference += 1.0 - y_norm[i];

        }
        else if(x.penalty_cycle_accum[i] < y.penalty_cycle_accum[i])
        {
            y_norm[i] = 1.0;
            x_norm[i] = (double) x.penalty_cycle_accum[i] / (double) y.penalty_cycle_accum[i];

            // Save CPs with unique paths
            if(x.penalty_cycle_accum[i] == 0 && UNIQ_LOCAL == true)
                return 0;

            y_count++;
            y_preference += 1.0 - x_norm[i];
        }
        else
        {
            x_norm[i] = 1.0;
            y_norm[i] = 1.0;
            empty_count++;
        }

        /*
        // Temp log output function
        if(global_cntr == 2000)
        {
        cerr << "X: " << x.penalty_cycle_accum[i] << "  Y: " << y.penalty_cycle_accum[i]
        << "     XNrm: " << x_norm[i] << "  YNrm: " << y_norm[i] << endl;

        }
        */

    }


    double x_size = 0, y_size = 0;

    // First, get the sizes of the two vectors
    for (int i = 0; i < stack_entry_num; ++i)
    {
        x_size += x_norm[i] * x_norm[i];
        y_size += y_norm[i] * y_norm[i];
    }

    x_size = (double) sqrt(x_size);
    y_size = (double) sqrt(y_size);

    double inner_prod = 0;
    // Second, get the inner product
    for (int i = 0; i < stack_entry_num; ++i)
    {
        inner_prod += x_norm[i] * y_norm[i];
    }

    double similarity = inner_prod / (x_size*y_size);

    //cerr << "[Summary] XPref: " << x_preference << "  YPref: " << y_preference
    //		<< "  Sim: " << similarity << "  Xcount: " << x_count << "  Ycount: " << y_count << "  Ecount: " << empty_count << endl;

    if(similarity >= COS_TH_LOCAL)
    {
        // Save sharing paths
        if(SHARE)
        {
            //  Do not merge nosharing & sharing paths
            if((x.is_sharing == false && y.is_sharing == true) || (y.is_sharing == false && x.is_sharing == true))
            {
                return 0;
            }
        }

        // Similar and keep x
        if(x.weight() > y.weight())
            return -1;
        else
            return 1;
    }
    else
    {
        // If one path is dominant, keep only the larger one
        // X is dominant
        if(x_count+empty_count == stack_entry_num)
            return -1;
        else if(y_count+empty_count == stack_entry_num)
            return 1;

        // Not similar: keep both
        return 0;
    }

}

bool cp::bigger(const cp &i, const cp &j){
    return i.weight() > j.weight();
}

bool cp::bigger_base(const cp &i, const cp &j){
    return i.penalty_cycle_accum[base] > j.penalty_cycle_accum[base];
}

double _diff (u_int64_t a, u_int64_t b, u_int64_t max){
    double diff = (double) a - b;
    if (diff < 0)
        diff = -diff;
    return diff / max * 100;
}

bool _v_is_similar(const u_int64_t *v1, const u_int64_t *v2, u_int64_t v1_sum, u_int64_t v2_sum,
                   int weight_percent, int entry_percent){
    u_int64_t max = v1_sum > v2_sum ? v1_sum : v2_sum;

    if (!max)
        return true;

    if (_diff(v1_sum, v2_sum, max) > weight_percent){
        return false;
    }

    for (int i = 0; i < stack_entry_num; ++i){
        if (_diff(v1[i], v2[i], max) > entry_percent)
            return false;
    }

    return true;
}

// New cos reduction
bool is_similar_cos(const cp &x, const cp &y, bool printer)
{
    if(cpcmp_cos(x, y, COS_TH, UNIQ))
    {
        /*
          if(!printer)
          {
          cerr << "Reduction by cosine similarity" << endl;
          }
        */
        return true;
    }

    return false;
}

bool is_similar(const cp &x, const cp &y, int weight_percent, int entry_percent, bool skip_phase)
{

    //First phase
    if (!skip_phase){
        bool first_pass = _v_is_similar(x.penalty_cycle, y.penalty_cycle, x._weight, y._weight,
                                        weight_percent, entry_percent);
        if (!first_pass)
            return false;
    }

    //Second phase
    bool second_pass = _v_is_similar(x.penalty_cycle_accum, y.penalty_cycle_accum, x.accum_weight, y.accum_weight,
                                     weight_percent, entry_percent);

    return second_pass;
}

ostream & operator <<(ostream &os, const cp& s){
    return s.print(os);
}

bool valid(const cp & ent){
    return ent.isvalid();
}

void cp_update(vector<cp> src, edge &e, vector<cp> &dest, int src_stage, bool select)
{
    if (src.empty())
        src.push_back(cp());

    // Perform comparison & merging operation
    // Compare using groupby -- compare only the paths in the same category
    vector<cp> src_selected;

    // Apply COS similarity based merging
    int cmp_cnt = 0;

    for (vector<cp>::iterator src_it = src.begin(); src_it != src.end(); ++src_it)
    {
        src_it->update(e, src_stage);
        bool discard = false;

        for (vector<cp>::iterator dest_it = dest.begin(); dest_it != dest.end(); ++dest_it)
        {
            if (!select)
            {
                discard = true;
                if (dest_it->weight() < src_it->weight())
                    *dest_it = *src_it;

                cmp_cnt++;
            }
            else if(src_it->get_hash() == dest_it->get_hash())
            {
                int comp;
                cmp_cnt++;

                // Perform comparison
                // SAVEUNIQ is active only when both paths have size less than uniq_threshold
                int uniq_threshold = UNIQ_LEN;
                if (src_it->weight() > uniq_threshold || dest_it->weight() > uniq_threshold || (UNIQ == false))
                  comp = cpcmp_cos(*src_it, *dest_it, COS_TH, false);
                else
                  comp = cpcmp_cos(*src_it, *dest_it, COS_TH, true);

                // Keep destination
                if (comp > 0)
                {
                    discard = true;
                    break;
                }
                // Keep source
                else if (comp < 0)
                    dest_it->invalidate();

                // If comp == 0, keep both paths
            }
        }

        // Remove invalidated paths from 'dest' vector.
        vector<cp>::iterator bound;
        bound = partition(dest.begin(), dest.end(), valid);
        dest.erase(bound, dest.end());

        if (!discard)
            src_selected.push_back(*src_it);
    }

    copy(src_selected.begin(), src_selected.end(), back_inserter(dest));

}

void delete_redundancy(vector<cp> &src, int weight_percent, int entry_percent, bool skip)
{
    int alive = 0;
    for (int i = 0; i < src.size(); ++i)
    {
        if (!src[i].isvalid())
            continue;

        alive = i;

        for (int j = i + 1; j < src.size(); ++j)
        {
            if (!src[j].isvalid())
                continue;

            if (is_similar(src[alive], src[j], weight_percent, entry_percent, skip))
            {
                if (src[alive].weight() > src[j].weight())
                    src[j].invalidate();
                else
                {
                    src[alive].invalidate();
                    alive = j;
                }
            }
        }
    }

    vector<cp>::iterator bound;
    bound = partition(src.begin(), src.end(), valid);
    src.erase(bound, src.end());

    for (vector<cp>::iterator it = src.begin(); it != src.end(); ++it){
        it->local_init();
    }
}

void print_cps(ostream &os, vector<cp> &cps, int weight_percent, int entry_percent){
    os << "Critical Path" << endl;
    for (vector<cp>::const_iterator it = cps.begin();
         it != cps.end(); ++it)
        os << *it;

    os << "Reduced Path" << endl;
    delete_redundancy(cps, weight_percent, entry_percent, true);
    for (vector<cp>::const_iterator it = cps.begin();
         it != cps.end(); ++it)
        os << *it;
}
