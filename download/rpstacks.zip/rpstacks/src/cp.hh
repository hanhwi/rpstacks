// Copyright 2014 Hanhwi Jang, Jaewon Lee, Jae-Eon Jo, and Jangwoo Kim

// Redistribution and  use in  source and binary  forms, with  or without
// modification, are permitted provided that the following conditions are
// met:

// 1.  Redistributions of  source code  must retain  the above  copyright
// notice, this list of conditions and the following disclaimer.

// 2. Redistributions in  binary form must reproduce  the above copyright
// notice, this  list of conditions  and the following disclaimer  in the
// documentation and/or other materials provided with the distribution.

// 3.  Neither the  name of  the copyright  holder nor  the names  of its
// contributors may be  used to endorse or promote  products derived from
// this software without specific prior written permission.

// THIS SOFTWARE  IS PROVIDED BY  THE COPYRIGHT HOLDERS  AND CONTRIBUTORS
// "AS  IS" AND  ANY EXPRESS  OR IMPLIED  WARRANTIES, INCLUDING,  BUT NOT
// LIMITED TO, THE IMPLIED WARRANTIES  OF MERCHANTABILITY AND FITNESS FOR
// A PARTICULAR PURPOSE  ARE DISCLAIMED. IN NO EVENT  SHALL THE COPYRIGHT
// HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
// SPECIAL,  EXEMPLARY,  OR  CONSEQUENTIAL DAMAGES  (INCLUDING,  BUT  NOT
// LIMITED TO, PROCUREMENT OF SUBSTITUTE  GOODS OR SERVICES; LOSS OF USE,
// DATA, OR PROFITS; OR BUSINESS  INTERRUPTION) HOWEVER CAUSED AND ON ANY
// THEORY OF  LIABILITY, WHETHER IN  CONTRACT, STRICT LIABILITY,  OR TORT
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN  ANY WAY OUT OF THE USE
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

#ifndef _CP_HH
#define _CP_HH
#include <iostream>
#include <sys/types.h>
#include "inst.hh"
#include "merge.hh"

// Predefined min and max latency of events
const int l1i_lat_default = 2;
const int l1d_lat_default = 4;
const int l2i_lat_default = 12;
const int l2d_lat_default = 12;
const int sht_alu_default = 1;

const int l2i_lat_min = 0;
const int l2d_lat_min = 0;
const int mem_lat_min = 0;

const int l2i_lat_max = 12;
const int l2d_lat_max = 12;
const int mem_lat_max = 133;

/*
enum stack_entry {base, itlb, dtlb, l1i, l2i, l1d, l2d, lat, br, stack_entry_num};
enum stack_entry {
  base,
  l1i, l1d, l2i, l2d,
  mem_i, mem_d,
  l1_itlb, l2_itlb, mem_itlb,
  l1_dtlb, l2_dtlb, mem_dtlb,
  alu_int_mul, alu_int_div,
  alu_fp_addsub,
  alu_fp_muldiv,
  br,
  stack_entry_num
};
*/
// 140508 Stack entry -- fixed
enum stack_entry {
  base,
  l1i, l1d, l2i, l2d,
  mem_i, mem_d,
  alu_int_mul, alu_int_div,
  alu_fp_addsub,
  alu_fp_muldiv,
  basealu,
  stack_entry_num
};


class cp
{
  friend std::ostream & operator <<(std::ostream &os, const cp& s);
  friend bool is_similar(const cp &x, const cp &y, int weight_percent, int entry_percent,
			 bool skip_phase);
  friend int64_t cpcmp(const cp &x, const cp &y);
  friend int64_t cpcmp_cos(const cp &x, const cp &y, double, bool);
private:
  u_int64_t _weight;
  u_int64_t accum_weight;
  u_int64_t penalty_cycle[stack_entry_num];
  u_int64_t penalty_cycle_accum[stack_entry_num];
  u_int64_t l1d_counter;
  u_int64_t l2d_counter;
  u_int64_t l1i_counter;
  u_int64_t l2i_counter;
  u_int64_t memi_counter;
  u_int64_t memd_counter;
  u_int64_t bank_sharing;
  u_int64_t l1_sharing;
  u_int64_t l2_sharing;
  u_int64_t alu_counter;
  u_int64_t lat_counter;
  u_int64_t l1_sharing_weight;
  u_int64_t hash;
  // Extra counters for base
  // u_int64_t fetchwlimit;
  // u_int64_t dispatchwlimit;
  // u_int64_t frontendwlimit;
  // u_int64_t commitwlimit;
  // u_int64_t fetch_dispatch_counter;
  // u_int64_t mem_shortage_counter;
  // u_int64_t reg_shortage_counter;
  // u_int64_t rob_shortage_counter;
  // u_int64_t fu_shortage_counter;
  // u_int64_t tfer_counter;
  // u_int64_t datadep_counter;
  // u_int64_t memaddr_counter;
  // u_int64_t fubase_counter;
  // u_int64_t commitbase_counter;
  // u_int64_t retire_counter;
  // char fetch_counter;
  // char rename_counter;
  // char dispatch_counter;
  // char commit_counter;
  bool valid;
  bool ismax;
  int last_visit_stage;
  int last_visit_distance;
  bool is_sharing;
public:
  cp();
  void init();
  void local_init();
  bool isvalid() const;
  void invalidate();
  u_int64_t weight() const;
  u_int64_t get_base() const;
  u_int64_t get_hash() const;
  void update(edge &e, int src_stage);
  void update_hash();
  std::ostream &print(std::ostream &os) const;
  static bool bigger(const cp &i, const cp &j);
  static bool bigger_base(const cp &i, const cp &j);
};

std::ostream & operator <<(std::ostream &os, const cp& s);
int64_t cpcmp(const cp &x, const cp &y);
int64_t cpcmp_cos(const cp &x, const cp &y, double, bool);
bool is_similar(const cp &x, const cp &y, int weight_percent, int entry_percent, bool skip_phase = false);

extern bool option_marker;

//Select is true, cp_update uses critical path length as comparator.
void cp_update(std::vector<cp> src, edge &e, std::vector<cp> &dest, int src_stage, bool select);
void delete_redundancy(std::vector<cp> &src, int weight_percent, int entry_percent, bool skip=false);
void print_cps(std::ostream &os, std::vector<cp> &cps, int weight_percent, int entry_percent);
#endif
