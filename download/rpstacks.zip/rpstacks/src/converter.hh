// Copyright 2014 Hanhwi Jang, Jaewon Lee, Jae-Eon Jo, and Jangwoo Kim

// Redistribution and  use in  source and binary  forms, with  or without
// modification, are permitted provided that the following conditions are
// met:

// 1.  Redistributions of  source code  must retain  the above  copyright
// notice, this list of conditions and the following disclaimer.

// 2. Redistributions in  binary form must reproduce  the above copyright
// notice, this  list of conditions  and the following disclaimer  in the
// documentation and/or other materials provided with the distribution.

// 3.  Neither the  name of  the copyright  holder nor  the names  of its
// contributors may be  used to endorse or promote  products derived from
// this software without specific prior written permission.

// THIS SOFTWARE  IS PROVIDED BY  THE COPYRIGHT HOLDERS  AND CONTRIBUTORS
// "AS  IS" AND  ANY EXPRESS  OR IMPLIED  WARRANTIES, INCLUDING,  BUT NOT
// LIMITED TO, THE IMPLIED WARRANTIES  OF MERCHANTABILITY AND FITNESS FOR
// A PARTICULAR PURPOSE  ARE DISCLAIMED. IN NO EVENT  SHALL THE COPYRIGHT
// HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
// SPECIAL,  EXEMPLARY,  OR  CONSEQUENTIAL DAMAGES  (INCLUDING,  BUT  NOT
// LIMITED TO, PROCUREMENT OF SUBSTITUTE  GOODS OR SERVICES; LOSS OF USE,
// DATA, OR PROFITS; OR BUSINESS  INTERRUPTION) HOWEVER CAUSED AND ON ANY
// THEORY OF  LIABILITY, WHETHER IN  CONTRACT, STRICT LIABILITY,  OR TORT
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN  ANY WAY OUT OF THE USE
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

#ifndef _CONV_HH
#define _CONV_HH

#include <string>
#include <vector>
#include "queue.hh"
#include "stat.hh"
#include "cp.hh"
#include "const.hh"

class converter{
public:
    void start(bool disable_itlb, bool disable_dtlb, bool disable_mpred, int l1d_lat,
               int l2i_lat, int l2d_lat, int mem_lat, int long_lat,
               int fadd_lat, int fmul_lat, int div_lat, int mul_lat,
               bool perfect_l1i, bool perfect_l1d, bool perfect_l2i, bool perfect_l2d,
               int weight_percent, int entry_percent);

    converter(int threshold, int interval, char *ofname);
private:
    static const int buffer_size = rob_size * StateNum * 4;
    static int idx;
    int num_of_cp;
    int prev_num_of_cp;
    int threshold;
    int interval;
    std::string ofprefix;
    bool dynamic_threshold;
    static_queue<state, buffer_size> buffer;
    static_queue<stat, buffer_size> stat_buffer;
    static_queue<std::vector<cp>, buffer_size> cp_buffer;
    static_queue<double, buffer_size> num_buffer;
    std::vector<std::pair<u_int64_t, stat> > issueq;
    stat _stat;
    bool load();
    void clear_cp_buffer();
    void issueq_insert(u_int64_t cycles, stat &s);
};

#endif
